import React, { Component } from 'react';
import "./OSBB.css"
import "../Main/Main.css"
import { Typography } from '@material-tailwind/react';
export default class EditUser extends Component {
constructor(props){
    super(props);

    this.state={
    };
}

render() {
    return (
        <div class="container mx-auto px-4 rounded-3xl bSty heightTo backimgAboutUs centered">
            <div class="about-section">
                <Typography variant='h1' color='gray'>Наша Организация</Typography>
                <Typography color='darkgray'>Some text about who we are and what we do.</Typography>
                <Typography color='darkgray'>Resize the browser window to see that this page is responsive by the way.</Typography>
            </div>

            <Typography variant='h2' color='gray' style={{textAlign:"center"}}>Что то тут тоже напишите</Typography>
            <div class="holder">
                <div class="card cont mx-auto px-4 rounded-3xl">
                <img class="imgProf" src='' alt="Mykyta"/>
                <div class="container">
                    <Typography variant='h2' color='gray'>------</Typography>
                    <Typography color='teal' variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            <div class="card cont mx-auto px-4 rounded-3xl">
                <img class="imgProf" src='' alt="Mykyta"/>
                <div class="container">
                    <Typography variant='h2' color='gray'>------</Typography>
                    <Typography color='teal' variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            </div>
            <div class="holder">
                <div class="card cont mx-auto px-4 rounded-3xl">
                <img class="imgProf" src='' alt="Mykyta"/>
                <div class="container">
                    <Typography variant='h2' color='gray'>------</Typography>
                    <Typography color='teal' variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            <div class="card cont mx-auto px-4 rounded-3xl">
                <img class="imgProf" src='' alt="Mykyta"/>
                <div class="container">
                    <Typography variant='h2' color='gray'>------</Typography>
                    <Typography color='teal' variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            </div>
            
        </div>
    )
    }
}