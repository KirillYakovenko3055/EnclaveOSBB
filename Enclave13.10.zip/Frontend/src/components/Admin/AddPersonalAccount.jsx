import React, { useState } from 'react';
import { Input, Button, Typography } from "@material-tailwind/react";
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';

const AddPersonalAccount = () => {
    const token = localStorage.getItem('token');
    const location = useLocation();
    const { OSBBId } = location.state || {};
    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        flatNum: '',
        totalArea: '',
        heatingArea: '',
        ownerId: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log(OSBBId);
        console.log("Request Data:", {
            flatNum: formData.flatNum,
            totalArea: formData.totalArea,
            heatingArea: formData.heatingArea,
            personId: formData.personId,
            typeId: formData.typeId,
        });
        try {
          console.log(`${import.meta.env.VITE_BACKEND_URL}/api/user/addPersonalAccount/${OSBBId}`);
            const response = await axios.post(
                `${import.meta.env.VITE_BACKEND_URL}/api/user/addPersonalAccount/${OSBBId}`,
                {
                    flatNum: formData.flatNum,
                    totalArea: formData.totalArea,
                    heatingArea: formData.heatingArea,
                    personId: formData.personId,
                    typeId: formData.typeId,
                },
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            console.log("2");
            console.log('Response:', response.data); // Отладка
            navigate(`/admin/${OSBBId}`);
        } catch (error) {
            console.error('Ошибка добавления квартиры:', error.response?.data || error);
        }
    };

    return (
        <div className="container mx-auto flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
  <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-md">
    <Typography variant="h4" color="blue" className="text-center mb-6">
      Добавить лицевой счет
    </Typography>
    <form onSubmit={handleSubmit}>
      <div className="mb-4">
        <Typography variant="small" color="gray" className="mb-2">
          Номер квартиры
        </Typography>
        <Input
          type="text"
          name="flatNum"
          value={formData.flatNum}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
          placeholder="Введите номер квартиры"
          required
        />
      </div>

      <div className="mb-4">
        <Typography variant="small" color="gray" className="mb-2">
          Общая площадь
        </Typography>
        <Input
          type="text"
          name="totalArea"
          value={formData.totalArea}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
          placeholder="Введите общую площадь"
          required
        />
      </div>

      <div className="mb-4">
        <Typography variant="small" color="gray" className="mb-2">
          Отапливаемая площадь
        </Typography>
        <Input
          type="text"
          name="heatingArea"
          value={formData.heatingArea}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
          placeholder="Введите отапливаемую площадь"
          required
        />
      </div>

      <div className="mb-4">
        <Typography variant="small" color="gray" className="mb-2">
          ID владельца (personId)
        </Typography>
        <Input
          type="text"
          name="personId"
          value={formData.personId}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
          placeholder="Введите ID владельца"
          required
        />
      </div>

      <div className="mb-4">
        <Typography variant="small" color="gray" className="mb-2">
          ID типа лицевого счета (typeId)
        </Typography>
        <Input
          type="text"
          name="typeId"
          value={formData.typeId}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
          placeholder="Введите тип лицевого счета"
          required
        />
      </div>

     {/* <div className="mb-4">
        <Typography variant="small" color="gray" className="mb-2">
          Номер лицевого счета (сгенерированный)
        </Typography>
        <Input
          type="text"
          name="personalNumber"
          value={formData.personalNumber || `PA-${Math.floor(Math.random() * 100)}`}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
          placeholder="Номер лицевого счета"
          required
          disabled
        />
      </div>*/}

      <Button type="submit" fullWidth variant="gradient" color="blue">
        Добавить
      </Button>
    </form>
  </div>
</div>


    );
};

export default AddPersonalAccount;
