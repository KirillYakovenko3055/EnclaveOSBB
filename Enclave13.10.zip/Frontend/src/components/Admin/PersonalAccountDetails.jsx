import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const PersonalAccountDetails = () => {
  const token = localStorage.getItem('token');
  const { personalAccountId } = useParams();
  const [accountDetails, setAccountDetails] = useState(null);
  const [owner, setOwner] = useState(null);
  const [residents, setResidents] = useState([]);

  useEffect(() => {
    const fetchAccountDetails = async () => {
      try {
        // Получаем основные данные о лицевом счете
        const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/accountdetails/${personalAccountId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setAccountDetails(response.data);
        console.log('Account Details:', response.data.accountDetails);
      } catch (error) {
        console.error('Ошибка получения данных о лицевом счете:', error);
      }
    };

    const fetchOwnerAndResidents = async () => {
      try {
        // Получаем данные о владельце и жильцах
        const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/accountresidentsowners/${personalAccountId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setOwner(response.data.owner);
        setResidents(response.data.residents || []);
        console.log('Owner and Residents:', response.data);
      } catch (error) {
        console.error('Ошибка получения данных о владельце и жильцах:', error);
      }
    };

    fetchAccountDetails();
    fetchOwnerAndResidents();
  }, [personalAccountId]);

  if (!accountDetails) {
    return <div>Загрузка...</div>;
  }
  /*const handleUpdatePersonalAccount = (flatNum, totalArea, heatingArea, personalNumber, typeName) => {
    // Проверяем, что все необходимые данные присутствуют
    if (flatNum && totalArea && heatingArea && personalNumber && typeName) {
        localStorage.setItem("PersonalAccountFlatNum", flatNum);
        localStorage.setItem("PersonalAccountTotalArea", totalArea);
        localStorage.setItem("PersonalAccountHeatingArea", heatingArea);
        localStorage.setItem("PersonalAccountPersonalNumber", personalNumber);
        localStorage.setItem("PersonalAccountType", typeName);

        navigate('/admin/add-personal-account', {
            state: {
                flatNum,
                totalArea,
                heatingArea,
                personalNumber,
                typeName
            }
        });
    } else {
        console.error("Одно или несколько обязательных полей отсутствуют.");
    }
};*/
  return (
    <div>
      <h2>Детали лицевого счета</h2>
      <p>Номер квартиры: {accountDetails.accountDetails.flatNum ? accountDetails.accountDetails.flatNum : "Неизвестно"}</p>
      <p>Общая площадь: {accountDetails.accountDetails.totalArea ? accountDetails.accountDetails.totalArea : "Неизвестно"}</p>
      <p>Отопительная площадь: {accountDetails.accountDetails.heatingArea ? accountDetails.accountDetails.heatingArea : "Неизвестно"}</p>
      <p>Лицевой номер: {accountDetails.accountDetails.personalNumber ? accountDetails.accountDetails.personalNumber : "Неизвестно"}</p>
      <p>Тип лицевого счета: {accountDetails.type ? accountDetails.type.name : "Неизвестно"}</p>
      {/*<Button
                className="mt-6"
                onClick={() => handleUpdatePersonalAccount(accountDetails.accountDetails.flatNum,
                   accountDetails.accountDetails.totalArea,
                    accountDetails.accountDetails.heatingArea,
                     accountDetails.accountDetails.personalNumber,
                      accountDetails.type ? accountDetails.accountDetails.typeId : null)}
                variant="gradient"
                color="blue"
            >
                Обновить
            </Button>*/}
      <br />
      {/* Данные о владельце */}
      {owner ? (
        <div>
          <h2>Владелец квартиры</h2>
          <p>ФИО: {owner.firstname} {owner.lastname}</p>
          <p>Телефон: {owner.phone}</p>
          <p>Email: {owner.email}</p>
        </div>
      ) : (
        <p>Владелец не найден</p>
      )}
      <br />

      {/* Данные о жильцах */}
      {residents.length > 0 ? (
        <div>
          <h2>Жильцы квартиры</h2>
          <ul>
            {residents.map((resident) => (
              <li key={resident._id}>
                {resident.firstname} {resident.lastname} — Телефон: {resident.phone}, Email: {resident.email}
              </li>
            ))}
          </ul>
        </div>
      ) : (
        <p>Жильцы не найдены</p>
      )}
    </div>
  );
};

export default PersonalAccountDetails;
