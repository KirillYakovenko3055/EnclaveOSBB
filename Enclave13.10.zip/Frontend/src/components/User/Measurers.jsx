import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Measurers = () => {
    const [measurers, setMeasurers] = useState([]);
    const token = localStorage.getItem('token');
    const accountId = localStorage.getItem('accountId');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchMeasurers = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/measurers/${accountId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setMeasurers(response.data.measurers);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchMeasurers();
    }, []);

    const handleMeasurerClick = async (measurerId) => {
        try {
            localStorage.setItem("measurerId", measurerId);
            navigate(`/user/measurer/${measurerId}`);
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };

    return (
        <div style={{height: '100%'}}>
            <h1>Список счетчиков</h1>
            <h2>Ваши счетчики:</h2>
            <ul>
            {measurers.map(measurer => (
                <li key={measurer._id} onClick={() => handleMeasurerClick(measurer._id)}>
                    {measurer.number}
                </li>
            ))}
            </ul>
        </div>
    );
};

export default Measurers;