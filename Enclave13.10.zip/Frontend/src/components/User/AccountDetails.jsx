import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';

const AccountDetails = () => {
    const location = useLocation();
    const token = localStorage.getItem('token');
    const { accountData } = location.state || {};
    const [additionalData, setAdditionalData] = useState(null);

    if (!accountData) {
        return <div>Нет данных об аккаунте</div>;
    }

    useEffect(() => {
        const fetchAccountDetails = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/accountdetails/${accountData._id}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                localStorage.setItem('accountId', accountData._id);
                setAdditionalData(response.data);

            } catch (error) {
                console.error('Ошибка получения данных по счету:', error);
            }
        };

        fetchAccountDetails();
    }, [accountData._id, token]); 

    if (!additionalData) {
        return <div>Загрузка информации...</div>;
    }

    return (
        <div style={{height: '100%'}}>
            <h1>Информация о счете {accountData.personalNumber}</h1>
            <ul>
                <li>
                    Город: {additionalData.city?.name || 'Данные отсутствуют'}
                </li>
                <li>
                    Улица: {additionalData.street?.name || 'Данные отсутствуют'}
                </li>
                <li>
                    Номер здания: {additionalData.building?.buildingNum || 'Данные отсутствуют'}
                </li>
                <li>
                    Номер квартиры: {accountData.flatNum || 'Данные отсутствуют'}
                </li>
                <li>
                    Площадь квартиры: {accountData.totalArea || 'Данные отсутствуют'}
                </li>
                <li>
                    Отапливаемая площадь: {accountData.heatingArea || 'Данные отсутствуют'}
                </li>
                <li>
                    Тип аккаунта: {additionalData.type?.name || 'Данные отсутствуют'}
                </li>
            </ul>
        </div>
    );
};

export default AccountDetails;
