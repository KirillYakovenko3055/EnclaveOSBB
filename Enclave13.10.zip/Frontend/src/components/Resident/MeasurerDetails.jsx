import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import axios from 'axios';
import Header from '../Main/Header'
import Footer from '../Main/Footer'

const MeasurerDetails = () => {
    const token = localStorage.getItem('token');
    const location = useLocation();
    const [additionalData, setAdditionalData] = useState(null);
    const { measurerId } = location.state || {};

    useEffect(() => {
        const fetchMeasurerDetails = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/measurer/${measurerId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setAdditionalData(response.data);
            } catch (error) {
                console.error('Ошибка получения данных по счету:', error);
            }
        };

        fetchMeasurerDetails();
    }, [measurerId, token]);

    if (!additionalData) {
        return <div>Загрузка информации...</div>;
    }

    return (
        <div style={{ height: '100%' }}>
            <h1>Информация о счетчике {additionalData.measurer?.number || 'Данные отсутствуют'}</h1>
            <ul>
                <li>
                    Тип: {additionalData.type?.type || 'Данные отсутствуют'}
                </li>
                <li>
                    Время действия: {additionalData.measurersToAccounts?.startDate ? new Date(additionalData.measurersToAccounts.startDate).toISOString().split('T')[0] : 'Данные отсутствуют'} - {additionalData.measurersToAccounts?.endDate ? new Date(additionalData.measurersToAccounts.endDate).toISOString().split('T')[0] : 'Данные отсутствуют'}
                </li>
                <li>
                    Код производителя: {additionalData.measurersToAccounts?.vendorCode || 'Данные отсутствуют'}
                </li>
            </ul>
            <h2>История показаний счетчика</h2>
            <ul>
                {additionalData.records.map(record => (
                    <li key={record._id}>
                        Дата: {new Date(record.date).toISOString().split('T')[0] } Показание: {record.value}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default MeasurerDetails;
