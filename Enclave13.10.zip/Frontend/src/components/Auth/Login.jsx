import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import '../../App.css'
import {
  Card,
  Input,
  Checkbox,
  Button,
  Typography,
  Alert,
} from "@material-tailwind/react";

const LoginForm = () => {
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/auth/login`, { login, password }, { withCredentials: true });
      setMessage(response.data.message);
      localStorage.setItem('login', login);
      navigate('/verify');
    } catch (error) {
      console.log(error);
      setMessage(error.response?.data?.message || 'Ошибка входа');
    }
  };

  return (
    <div className="container mx-auto px-4 rounded-3xl centered" style={{ textAlign: "center" }}>
      <Card color="transparent" shadow={false} >
        <Typography variant="h3" className="text-light-blue-500">
          Вхід
        </Typography>
        <center>
          <form className="mt-8 mb-2 w-80 max-w-screen-lg sm:w-96" onSubmit={handleLogin}>
            <div className="mb-1 flex flex-col gap-6">
              <Typography variant="h6" className="-mb-3 text-light-blue-300">
                Логін
              </Typography>
              <Input
                type="text"
                size="lg"
                className=" !border-t-blue-gray-200 focus:!border-t-gray-900 bg-white"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                required
              />
              <Typography variant="h6" className="-mb-3 text-light-blue-300">
                Пароль
              </Typography>
              <Input
                type="password"
                size="lg"
                placeholder="********"
                className=" !border-t-blue-gray-200 focus:!border-t-gray-900 bg-white"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

            </div>
            <Button className="mt-6" fullWidth type="submit" variant="gradient" color="blue">
              Підтвердити
            </Button>
          </form>{message && <p>{message}</p>}</center>
      </Card>
    </div>
  );
};

export default LoginForm;
