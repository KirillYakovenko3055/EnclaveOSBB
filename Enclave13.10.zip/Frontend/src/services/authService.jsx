import axios from 'axios';

const API_URL = 'https://develop.d34y77t6v7zy02.amplifyapp.com/api/auth';

export const LoginService = async (login, password) => {
  try {
    const response = await axios.post(`${API_URL}/login`, { login, password });
    if (response.data.token) {
      localStorage.setItem('user', JSON.stringify(response.data));
    }
    return response.data;
  } catch (error) {
    throw error.response.data.message;
  }
};

export const logout = () => {
  localStorage.removeItem('user');
};

export const RegisterService = async (login, password, email) => {
  try {
    const response = await axios.post(`${API_URL}/register`, { login, password, email });
    return response.data;
  } catch (error) {
    throw error.response.data.message;
  }
};

export const getCurrentUser = () => {
  return JSON.parse(localStorage.getItem('user'));
};
