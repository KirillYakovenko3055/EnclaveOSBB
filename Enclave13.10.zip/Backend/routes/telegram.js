const express = require('express');
const router = express.Router();
const telegramController = require('../controllers/telegramController');
const authMiddleware = require('../middlewares/authMiddleware');

router.post('/login', telegramController.telegramLogin);
router.post('/verify-code', telegramController.verifyCode);
router.get('/accounts/:chatId', authMiddleware(['user']), telegramController.getAccounts);
router.get('/measurers/:accountId', authMiddleware(['user']), telegramController.getMeasurers);
router.get('/measurements/:measurerId', authMiddleware(['user']),  telegramController.getMeasurerRecords);
router.get('/services/:accountId', authMiddleware(['user']),  telegramController.getActiveServices);
router.get('/check-token', authMiddleware(['user']), (req, res) => {
    res.json({ valid: true, user: req.user });
  });
module.exports = router;
