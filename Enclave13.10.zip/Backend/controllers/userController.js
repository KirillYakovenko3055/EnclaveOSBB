const bcrypt = require('bcryptjs');
const { getDB } = require('../config/db');
const { ObjectId } = require('mongodb');
const { use } = require('../routes/auth');

exports.createUser = async (req, res) => {
  const { login, email, password, phone, status, role, chatId } = req.body;

  if (!login || !email || !password || !phone || !status || !role) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const allowedStatuses = ['active', 'inactive', 'banned'];
  const allowedRoles = ['admin', 'user'];
  
  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ message: 'Invalid status value' });
  }
  
  if (!allowedRoles.includes(role)) {
    return res.status(400).json({ message: 'Invalid role value' });
  }

  const db = getDB();
  const usersCollection = db.collection('users');

  const userExists = await usersCollection.findOne({ $or: [{ login }, { email }] });
  if (userExists) {
    return res.status(400).json({ message: 'User with this login or email already exists' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const newUser = {
    login,
    email,
    password: hashedPassword,
    phone,
    status,
    role,
    chatId: chatId || null,
    registration_date: new Date(),
  };

  try {
    await usersCollection.insertOne(newUser);
    res.status(201).json({ message: 'User created successfully', userId: newUser._id });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getAccounts = async (req, res) => {
  const { login } = req.params;
  try {
    const db2 = getDB();

    const usersCollection = db2.collection('users');
    const userToPersonalAccountsCollection = db2.collection('userstopersonalaccounts');
    const personalAccountsCollection = db2.collection('personalaccounts');
    const personslCollection = db2.collection('persons');
    const residentToPersonalAccountsCollection = db2.collection('residentstopersonalaccounts');

    const user = await usersCollection.findOne({ login: login });
    if (!user) {
        console.log(`Пользователь с логином "${login}" не найден.`);
        return [];
    }

    const userToAccounts = await userToPersonalAccountsCollection.find({ userId: user._id }).toArray();
    const personalAccountIds = userToAccounts.map(entry => entry.personalAccountId);
    const accounts = await personalAccountsCollection.find({ _id: { $in: personalAccountIds } }).toArray();
    
    const residentToAccounts = await residentToPersonalAccountsCollection.find({ personalAccountId: { $in: personalAccountIds } }).toArray();
    const personsIds = residentToAccounts.map(entry => entry.personaId);
    const persons = await personslCollection.find({ _id: { $in: personsIds } }).toArray();

    res.json({
      accounts: accounts,
      person: persons
    });
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getAccount = async (req, res) => {
  const { accountId } = req.params;
  try {
    const db2 = getDB();
    const personalAccountsCollection = db2.collection('personalaccounts');
    const account = await personalAccountsCollection.findOne({_id: new ObjectId(accountId)});

    res.json(account);
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getAccountDetails = async (req, res) => {
  const { accountId } = req.params;
  try {
    const db2 = getDB();
    const personalAccountsCollection = db2.collection('personalaccounts');
    const typeAccountCollection = db2.collection('typepersonalaccounts');
    const buildingsCollection = db2.collection('buildings');
    const cityCollection = db2.collection('cities');
    const streetCollection = db2.collection('streets');

    const account = await personalAccountsCollection.findOne({_id: new ObjectId(accountId)});
    const type = await typeAccountCollection.findOne({_id: new ObjectId(account.typeId)});
    const building = await buildingsCollection.findOne({_id: new ObjectId(account.buildingId)});
    const city = await cityCollection.findOne({_id: new ObjectId(building.cityId)}); 
    const street = await streetCollection.findOne({_id: new ObjectId(building.streetId)}); 

    res.json({
      building: building,
      city: city,
      street: street,
      type: type
    });
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getMeasurers = async (req, res) => {
  const { accountId } = req.params;
  try {
    const db2 = getDB();
    const personalAccountsCollection = db2.collection('personalaccounts');
    const measurersToAccountsCollection = db2.collection('measurerstopersonalaccounts');
    const measurersCollection = db2.collection('measurers');

    const account = await personalAccountsCollection.findOne({_id: new ObjectId(accountId)});
    const measurersToAccounts = await measurersToAccountsCollection.find({personalAccountId: new ObjectId(account._id)}).toArray();
    const measurersToAccountsIds = await measurersToAccounts.map(entry => entry.measurerId);
    const measurers = await measurersCollection.find({ _id: { $in: measurersToAccountsIds } }).toArray();

    res.json({
      measurers: measurers
    });
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getMeasurerDetails = async (req, res) => {
  const { measurerId } = req.params;
  try {
    const db2 = getDB();
    const measurersCollection = db2.collection('measurers');
    const typesCollection = db2.collection('measuretypes');
    const measurersToAccountsCollection = db2.collection('measurerstopersonalaccounts');
    const measurerRecordsCollection = db2.collection('measurerrecords');

    const measurersToAccounts = await measurersToAccountsCollection.findOne({measurerId: new ObjectId(measurerId)});
    const measurer = await measurersCollection.findOne({ _id: new ObjectId(measurerId) });
    const type = await typesCollection.findOne({ _id: measurer.typeId });
    const records = await measurerRecordsCollection.find({ measurerToPersonalAccountId: measurersToAccounts._id }).toArray();

    res.json({
      type: type,
      measurer: measurer,
      measurersToAccounts: measurersToAccounts,
      records: records
    });
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getServices = async (req, res) => {
  const { accountId } = req.params;
  const currentDate = new Date();

  try {
    const db2 = getDB();

    const activeServices = await db2.collection('servicestopersonalaccounts').aggregate([
      {
        $match: {
          personalAccountId: new ObjectId(accountId),
          startDate: { $lte: currentDate },
          $or: [
            { endDate: { $gte: currentDate } },
            { endDate: null }
          ]
        }
      },
      {
        $lookup: {
          from: 'typeservices',
          localField: 'typeServiceId',
          foreignField: '_id',
          as: 'serviceDetails'
        }
      },
      {
        $unwind: '$serviceDetails'
      }
    ]).toArray();

    res.json(activeServices);

  } catch (error) {
    console.log(error);
    res.status(500).json({ message: 'Ошибка получения активных услуг' });
  }
};