const {initializeApp, cert} = require('firebase-admin/app');
const {getFirestore} = require('firebase-admin/firestore') 
const dayjs = require('dayjs');

const serviceAccount = require('../key.json');

initializeApp({
    credential: cert(serviceAccount)
})

const db = getFirestore();

async function deleteExpiredCodes() {
    try {
      const authCodesCollection = db.collection('authCodes');
      const now = dayjs();
      
      const authCodesSnapshot = await authCodesCollection.get();
  
      authCodesSnapshot.forEach(async (doc) => {
        const { timestamp } = doc.data();
      
        const codeTimestamp = dayjs(timestamp.toDate()); 
        const minutesDifference = now.diff(codeTimestamp, 'minute');
  
        if (minutesDifference > 5) {
          await authCodesCollection.doc(doc.id).delete();
          console.log(`Deleted expired auth code with ID: ${doc.id}`);
        }
      });
  
    } catch (error) {
      console.error('Error deleting expired auth codes:', error);
    }
  }

module.exports = { db, deleteExpiredCodes };
