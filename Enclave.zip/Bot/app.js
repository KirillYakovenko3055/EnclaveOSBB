require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');

const token = process.env.TELEGRAM_TOKEN;
const bot = new TelegramBot(token, { polling: true });
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const apiUrl = `${process.env.API_URL}/api/telegram`;
const userState = {};

function addUserState(chatId, stateData) {
  userState[chatId] = { ...stateData };
}

function formatDate(date) {
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();

  return `${day}/${month}/${year}`;
}

const helpText = `
/help - Показать список доступных команд.
/login - Войти в систему, введя логин и пароль.
/accounts - Показать все лицевые счета а также выбрать лицевой счет для просмотра информации о нем.
/measurers - Показать список счетчиков для выбранного лицевого счета и выбрать счетчик для просмотра информации.
/services - Показать все действующие сервисы.
`;

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "Введите комманду /help для получения информации о всех коммандах");
});

bot.onText(/\/help/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, helpText);
});

bot.onText(/\/login/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, 'Введите ваши логин и пароль в формате "<логин> <пароль>":');
  addUserState(chatId, { isLoggingIn: true, isAuthenticated: false });
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userInput = msg.text;

  if (userInput.startsWith('/')) {
    return;
  }

  if (userState[chatId] && userState[chatId].isLoggingIn) {
    const [login, password] = userInput.split(' ');

    if (!login || !password) {
      bot.sendMessage(chatId, 'Неверный формат. Введите логин и пароль в формате "<логин> <пароль>".');
      return;
    }

    try {
      const response = await axios.post(`${apiUrl}/login`, { login, password });
      bot.sendMessage(chatId, `Код отправлен на вашу почту (${response.data.email}). Введите код для подтверждения.`);
      userState[chatId].isLoggingIn = false;
      userState[chatId].isVerifyingCode = true;
    } catch (error) {
      bot.sendMessage(chatId, 'Ошибка при логине: ' + error.response?.data?.message || 'Неизвестная ошибка');
    }
  }
  else if (userState[chatId] && userState[chatId].isVerifyingCode) {
    const enteredCode = userInput;

    try {
      const response = await axios.post(`${apiUrl}/verify-code`, { chatId, code: enteredCode });
      bot.sendMessage(chatId, 'Успешная аутентификация!');
      userState[chatId].isAuthenticated = true;
      userState[chatId].token = response.data.token;
      delete userState[chatId].isVerifyingCode;
    } catch (error) {
      bot.sendMessage(chatId, 'Ошибка: ' + error.response?.data?.message || 'Неверный или просроченный код. Попробуйте еще раз.');
    }
  }
});

bot.onText(/\/accounts/, async (msg) => {
  const chatId = msg.chat.id;

  if (userState[chatId] && userState[chatId].isAuthenticated) {
    try {
      const response = await axios.get(`${apiUrl}/accounts/${chatId}`, {
        headers: { Authorization: `Bearer ${userState[chatId].token}` }
      });

      const accounts = response.data;

      if (accounts.length > 0) {
        const accountList = accounts.map((acc, index) => `${index + 1}. Лицевой счет: ${acc.personalNumber}`).join('\n');
        bot.sendMessage(chatId, `Ваши лицевые счета:\n${accountList}`);
        userState[chatId].accounts = accounts;
        bot.sendMessage(chatId, 'Введите порядковый номер лицевого счета, который хотите выбрать.');
        userState[chatId].isChoosingAccount = true;
      } else {
        bot.sendMessage(chatId, 'У вас нет связанных лицевых счетов.');
      }
    } catch (error) {
      bot.sendMessage(chatId, 'Ошибка: ' + error.response?.data?.message || 'Неизвестная ошибка');
    }
  } else {
    bot.sendMessage(chatId, 'Вы должны пройти аутентификацию. Введите команду /login.');
  }
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userInput = msg.text;

  if (userInput.startsWith('/')) {
    return;
  }

  if (userState[chatId]?.isChoosingAccount) {
    const accountIndex = parseInt(userInput) - 1;

    if (isNaN(accountIndex) || !userState[chatId].accounts || !userState[chatId].accounts[accountIndex]) {
      bot.sendMessage(chatId, 'Неверный выбор. Введите номер счета из списка.');
      return;
    }

    const selectedAccount = userState[chatId].accounts[accountIndex];
    await bot.sendMessage(chatId, `Вы выбрали лицевой счет: ${selectedAccount.personalNumber}`);

    userState[chatId].selectedAccount = selectedAccount._id;
    userState[chatId].selectedAccountNumber = selectedAccount.personalNumber;
    userState[chatId].isChoosingAccount = false;
  }
  else if (userState[chatId]?.isChoosingMeasurer) {
    const measurerIndex = parseInt(userInput) - 1;

    if (isNaN(measurerIndex) || !userState[chatId].measurers || !userState[chatId].measurers[measurerIndex]) {
      bot.sendMessage(chatId, 'Неверный выбор. Введите номер счетчика из списка.');
      return;
    }

    const selectedMeasurer = userState[chatId].measurers[measurerIndex];
    userState[chatId].selectedMeasurer = selectedMeasurer._id;
    await bot.sendMessage(chatId, `Вы выбрали счетчик: ${selectedMeasurer.service} (${selectedMeasurer.number})`);
    await bot.sendMessage(chatId, `Информация о счетчике:
       Время действия: ${formatDate(new Date(selectedMeasurer.startDate))} - ${formatDate(new Date(selectedMeasurer.endDate))}
       Код производителя: ${selectedMeasurer.vendorCode}
       `);
    try {
      const response = await axios.get(`${apiUrl}/measurements/${selectedMeasurer._id}`, {
        headers: { Authorization: `Bearer ${userState[chatId].token}` }
      });

      const records = response.data;
      if (Array.isArray(records) && records.length > 0) {
        const sortedRecords = records.sort((a, b) => new Date(b.date) - new Date(a.date));

        const recordList = sortedRecords.map(record => {
          const recordDate = record.date ? new Date(record.date).toLocaleDateString() : 'Дата неизвестна';
          const recordValue = record.value !== undefined ? record.value : 'Показание неизвестно';

          return `Дата: ${formatDate(new Date(recordDate))}, Показание: ${recordValue}`;
        }).join('\n');

        bot.sendMessage(chatId, `Записи счетчика:\n${recordList}`);
      }
      else {
        bot.sendMessage(chatId, `Записи не найдены для счетчика ${selectedMeasurer.typeMeasurer.number}.`);
      }
    } catch (error) {
      bot.sendMessage(chatId, 'Ошибка: ' + error.response?.data?.message || 'Неизвестная ошибка');
    }
  }
});

bot.onText(/\/measurers/, async (msg) => {
  const chatId = msg.chat.id;

  if (userState[chatId] && userState[chatId].selectedAccount && userState[chatId].isAuthenticated) {
    try {
      const response = await axios.get(`${apiUrl}/measurers/${userState[chatId].selectedAccount}`, {
        headers: { Authorization: `Bearer ${userState[chatId].token}` }
      });

      const measurers = response.data;

      if (measurers.length > 0) {
        bot.sendMessage(chatId, 'Введите порядковый номер счетчика, который хотите выбрать.');
        userState[chatId].isChoosingMeasurer = true;
        const measurerList = measurers.map((m, index) => `${index + 1}. ${m.service} (${m.number})`).join('\n');
        bot.sendMessage(chatId, `Счетчики для счета ${userState[chatId].selectedAccountNumber}:\n${measurerList}`);
        userState[chatId].measurers = measurers;
      } else {
        bot.sendMessage(chatId, `Счетчики не найдены для лицевого счета ${userState[chatId].selectedAccountNumber}.`);
      }
    } catch (error) {
      bot.sendMessage(chatId, 'Ошибка: ' + error.response?.data?.message || 'Неизвестная ошибка');
    }
  } else {
    bot.sendMessage(chatId, 'Вы должны выбрать лицевой счет с помощью команды /accounts.');
  }
});


bot.onText(/\/services/, async (msg) => {
  const chatId = msg.chat.id;

  if (userState[chatId] && userState[chatId].selectedAccount && userState[chatId].isAuthenticated) {
    try {
      const response = await axios.get(`${apiUrl}/services/${userState[chatId].selectedAccount}`, {
        headers: { Authorization: `Bearer ${userState[chatId].token}` }
      });

      const services = response.data;
      if (services.length > 0) {
        const serviceList = services.map((service, index) =>
`${index + 1}. ${service.serviceDetails.name} (начало: ${formatDate(new Date(service.startDate))}, окончание: ${service.endDate ? formatDate(new Date(service.endDate)) : 'без окончания'})`
        ).join('\n');

        bot.sendMessage(chatId, `Действующие услуги для счета ${userState[chatId].selectedAccountNumber}:\n${serviceList}`);
      } else {
        bot.sendMessage(chatId, `Нет действующих услуг для лицевого счета ${userState[chatId].selectedAccountNumber}.`);
      }
    } catch (error) {
      bot.sendMessage(chatId, 'Ошибка: ' + error.response?.data?.message || 'Неизвестная ошибка');
    }
  } else {
    bot.sendMessage(chatId, 'Вы должны выбрать лицевой счет с помощью команды /accounts.');
  }
});


