const express = require('express');
const router = express.Router();
const accountController = require('../controllers/accountController');
const measurersController = require('../controllers/measurersController');
const osbbController = require('../controllers/osbbController');
const paymentsController = require('../controllers/paymentsController');
const servicesController = require('../controllers/servicesController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/osbblist', authMiddleware(['admin']), osbbController.getOSBBList);
router.get('/osbbdetails/:OSBBId', authMiddleware(['admin']), osbbController.getOSBBDetails);
router.post('/updatedataosbb/:OSBBId/:BuildingId/:StreetId/:CityId', authMiddleware(['admin']), osbbController.updateOSBBDetails);
router.post('/deletedataosbb/:OSBBId/:BuildingId/:StreetId/:CityId', authMiddleware(['admin']), osbbController.deleteOSBB);
router.post('/insertdataosbb', authMiddleware(['admin']), osbbController.insertOSBB);
router.get('/accounts/:login', authMiddleware(['user', 'admin']), accountController.getAccounts);
router.get('/account/:accountId', authMiddleware(['user', 'admin']), accountController.getAccount);
router.get('/accountdetails/:accountId', authMiddleware(['user', 'admin']), accountController.getAccountDetails);
router.get('/measurers/:accountId', authMiddleware(['user', 'admin']), measurersController.getMeasurers);
router.get('/measurer/:measurerId', authMiddleware(['user', 'admin']), measurersController.getMeasurerDetails);
router.post('/insertdatameasurer/:measurertopersonalaccountId', authMiddleware(['admin']), measurersController.insertDataMeasurer);
router.post('/deletedatameasurer/:recordId', authMiddleware(['admin']), measurersController.deleteDataMeasurer);
router.post('/updatedatameasurer/:recordId', authMiddleware(['admin']), measurersController.updateDataMeasurer);
router.get('/services/:accountId', authMiddleware(['admin', 'user']), servicesController.getServices);
router.get('/payments/:accountId', authMiddleware(['admin', 'user']), paymentsController.getPayments);


module.exports = router;
