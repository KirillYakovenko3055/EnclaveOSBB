const nodemailer = require('nodemailer');
const crypto = require('crypto');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'enclaveosbb@gmail.com',
    pass: `${process.env.EMAIL_CODE}`
  }
});

const sendAuthCode = async (email, authCode) => {
  try {
    await transporter.sendMail({
      from: 'enclaveosbb@gmail.com',
      to: email,
      subject: 'Telegram Authentication Code',
      text: `Ваш код аутентификации: ${authCode}. Он действителен 5 минут.`
    });
    console.log('Email отправлен успешно');
  } catch (error) {
    console.error('Ошибка при отправке email:', error);
  }
};

function generateAuthCode() {
    return crypto.randomBytes(3).toString('hex').toUpperCase();
}
  
module.exports = { sendAuthCode, generateAuthCode };