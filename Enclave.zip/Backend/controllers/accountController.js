const bcrypt = require('bcryptjs');
const { getDB } = require('../config/db');
const { ObjectId } = require('mongodb');

exports.getAccounts = async (req, res) => {
  const { login } = req.params;
  try {
    const db2 = getDB();

    const usersCollection = db2.collection('users');
    const userToPersonalAccountsCollection = db2.collection('userstopersonalaccounts');
    const personalAccountsCollection = db2.collection('personalaccounts');
    const personslCollection = db2.collection('persons');
    const residentToPersonalAccountsCollection = db2.collection('residentstopersonalaccounts');

    const user = await usersCollection.findOne({ login: login });
    if (!user) {
      console.log(`Пользователь с логином "${login}" не найден.`);
      return [];
    }

    const userToAccounts = await userToPersonalAccountsCollection.find({ userId: user._id }).toArray();
    const personalAccountIds = userToAccounts.map(entry => entry.personalAccountId);
    const accounts = await personalAccountsCollection.find({ _id: { $in: personalAccountIds } }).toArray();

    const residentToAccounts = await residentToPersonalAccountsCollection.find({ personalAccountId: { $in: personalAccountIds } }).toArray();
    const personsIds = residentToAccounts.map(entry => entry.personaId);
    const persons = await personslCollection.find({ _id: { $in: personsIds } }).toArray();

    res.json({
      accounts: accounts,
      person: persons
    });
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getAccount = async (req, res) => {
  const { accountId } = req.params;
  try {
    const db2 = getDB();
    const personalAccountsCollection = db2.collection('personalaccounts');
    const account = await personalAccountsCollection.findOne({ _id: new ObjectId(accountId) });

    res.json(account);
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};

exports.getAccountDetails = async (req, res) => {
  const { accountId } = req.params;
  try {
    const db2 = getDB();
    const personalAccountsCollection = db2.collection('personalaccounts');
    const typeAccountCollection = db2.collection('typepersonalaccounts');
    const buildingsCollection = db2.collection('buildings');
    const cityCollection = db2.collection('cities');
    const streetCollection = db2.collection('streets');

    const account = await personalAccountsCollection.findOne({ _id: new ObjectId(accountId) });
    const type = await typeAccountCollection.findOne({ _id: new ObjectId(account.typeId) });
    const building = await buildingsCollection.findOne({ _id: new ObjectId(account.buildingId) });
    const city = await cityCollection.findOne({ _id: new ObjectId(building.cityId) });
    const street = await streetCollection.findOne({ _id: new ObjectId(building.streetId) });

    res.json({
      building: building,
      city: city,
      street: street,
      type: type
    });
  } catch (error) {
    console.error('Error fetching accounts by accountId:', error);
    return res.status(500).json({ message: 'Internal server error' });
  }
};