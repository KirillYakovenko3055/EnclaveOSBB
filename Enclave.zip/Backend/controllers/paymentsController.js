const bcrypt = require('bcryptjs');
const { getDB } = require('../config/db');
const { ObjectId } = require('mongodb');

exports.getPayments = async (req, res) => {
    const { accountId } = req.params;
    try {
      const db2 = getDB();
  
      const paymentsCollection = await db2.collection('payments');
  
      const payments = await paymentsCollection.find({personalAccountId: new ObjectId(accountId)}).toArray();
  
      res.json(payments);
    } catch (error) {
      console.log(error);
      res.status(500).json({ message: 'Ошибка получения активных услуг' });
    }
  };