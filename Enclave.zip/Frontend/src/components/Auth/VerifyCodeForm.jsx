import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  Card,
  Input,
  Checkbox,
  Button,
  Typography,
  Alert,
} from "@material-tailwind/react";

const VerifyCodeForm = () => {
  const [code, setCode] = useState('');
  const [message, setMessage] = useState('');

  const navigate = useNavigate();

  const handleVerifyCode = async (e) => {
    e.preventDefault();

    try {
      const login = localStorage.getItem('login');
      const response = await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/auth/verify-code`, { code, login });
      const { token, role } = response.data;

      localStorage.setItem('token', token);
      localStorage.setItem('role', role);

      if (role == 'admin') {
        navigate('/admin');
      } else if (role == 'user') {
        navigate('/user');
      } else {
        navigate('/');
      }
    } catch (error) {
      setMessage(error.response?.data?.message || 'Ошибка подтверждения');
    }
  };

  return (
    <div className="container mx-auto px-4 rounded-3xl bSty heightTo backimgInUp centered" style={{ textAlign: "center", height: "100%" }}>
      <Card color="transparent" shadow={false} >
        <Typography variant="h3" className="text-light-blue-500">
          Підтвердження коду
        </Typography>
        <center>
          <form className="mt-8 mb-2 w-70 max-w-screen-lg sm:w-46" onSubmit={handleVerifyCode}>
            <div>
              <Typography variant="h6" className="-mb-3 text-light-blue-300">
                Код из email:
              </Typography>
              <br />
              <Input
                type="text"
                size="lg"
                placeholder="********"
                className=" !border-t-blue-gray-200 focus:!border-t-gray-900 bg-white"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                required
              />
            </div>
            <Button className="mt-6" fullWidth type="submit" variant="gradient" color="blue">
              Підтвердити
            </Button>
          </form>{message && <p>{message}</p>}</center>
      </Card>
    </div>
  );
};

export default VerifyCodeForm;
