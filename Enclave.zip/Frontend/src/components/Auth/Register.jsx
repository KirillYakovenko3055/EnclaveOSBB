// import React, { useState } from 'react';
// import { register } from '../../services/authService';

// const Register = () => {
//   const [registerData, setRegisterData] = useState({ login: '', password: '', email: '' });
//   const [message, setMessage] = useState('');
//   const [error, setError] = useState('');

//   const handleChange = (e) => {
//     setRegisterData({ ...registerData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       await register(registerData.login, registerData.password, registerData.email);
//       setMessage('Пользователь успешно создан');
//       setError('');
//     } catch (err) {
//       setError(err);
//       setMessage('');
//     }
//   };

//   return (
//     <div>
//       <h2>Регистрация пользователя</h2>
//       <form onSubmit={handleSubmit}>
//         <div>
//           <label>Логин</label>
//           <input type="text" name="login" value={registerData.login} onChange={handleChange} />
//         </div>
//         <div>
//           <label>Пароль</label>
//           <input type="password" name="password" value={registerData.password} onChange={handleChange} />
//         </div>
//         <div>
//           <label>Email</label>
//           <input type="email" name="email" value={registerData.email} onChange={handleChange} />
//         </div>
//         {message && <p>{message}</p>}
//         {error && <p>{error}</p>}
//         <button type="submit">Зарегистрировать</button>
//       </form>
//     </div>
//   );
// };

// export default Register;
