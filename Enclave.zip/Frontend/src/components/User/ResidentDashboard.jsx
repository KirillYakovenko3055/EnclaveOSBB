import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const ResidentDashboard = () => {
    const [accounts, setAccounts] = useState([]);
    const [residentName, setResidentName] = useState([]);
    const token = localStorage.getItem('token');
    const login = localStorage.getItem('login');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchAccounts = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/accounts/${login}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setAccounts(response.data.accounts);
                setResidentName(response.data.person[0].firstname)
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchAccounts();
    }, []);

    const handleAccountClick = async (accountId) => {
        try {
            const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/account/${accountId}`, {
                headers: { Authorization: `Bearer ${token}` }
            });

            navigate(`/user/account/${accountId}`, { state: { accountData: response.data } });
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };
    return (
        <div style={{height: '100%'}}>
            <h1>Добро пожаловать {residentName}!</h1>
            <h2>Ваши счета:</h2>
            <ul>
            {accounts.map(account => (
                <li key={account._id} onClick={() => handleAccountClick(account._id)}>
                    {account.personalNumber}
                </li>
            ))}
            </ul>
        </div>
    );
};

export default ResidentDashboard;