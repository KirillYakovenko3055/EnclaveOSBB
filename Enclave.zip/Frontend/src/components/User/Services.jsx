import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Header from '../Main/Header';
import Footer from '../Main/Footer'

const Services = () => {
    const [services, setServices] = useState([]);
    const token = localStorage.getItem('token');
    const accountId = localStorage.getItem('accountId');

    useEffect(() => {
        const fetchServices = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/services/${accountId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setServices(response.data);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchServices();
    }, []);


    return (
        <div style={{height: '100%'}}>
            <h1>Список сервисов</h1>
            <h2>Ваши сервисы:</h2>
            <ul>
            {services.map(service => (
                <li key={service._id}>
                    Тип: {service.serviceDetails.name} Дата: {service?.startDate ? new Date(service.startDate).toISOString().split('T')[0] : 'Данные отсутствуют'} - {service?.endDate ? new Date(service.endDate).toISOString().split('T')[0] : 'без окончания'}
                </li>
            ))}
            </ul>
        </div>
    );
};

export default Services;