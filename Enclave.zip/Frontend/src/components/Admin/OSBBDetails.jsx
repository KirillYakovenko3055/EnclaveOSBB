import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
    Card,
    Input,
    Checkbox,
    Button,
    Typography,
    Alert,
} from "@material-tailwind/react";

const OSBBDetails = () => {
    const token = localStorage.getItem('token');
    const OSBBId = localStorage.getItem('OSBBId');
    const [additionalData, setAdditionalData] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchOSBBDetails = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/osbbdetails/${OSBBId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                localStorage.setItem('OSBBId', OSBBId);
                setAdditionalData(response.data);
            } catch (error) {
                console.error('Ошибка получения данных по счету:', error);
            }
        };

        fetchOSBBDetails();
    }, [OSBBId, token]); 


    const handleUpdateOSBB = (name, taxcode, buildingNum, streetname, cityname) => {
        if (additionalData?.name[0]) {
            localStorage.setItem("OSBBId", OSBBId);
            localStorage.setItem("BuildingId", additionalData.building._id);
            localStorage.setItem("StreetId", additionalData.street._id);
            localStorage.setItem("CityId", additionalData.city._id);
            navigate('/admin/add-OSBB-data', {
                state: { name: name, taxcode: taxcode, buildingNum: buildingNum, streetname: streetname, cityname: cityname }
            });
        } else {
            console.error("personalToAccountId отсутствует");
        }
    };

    const handleDeleteRecord = async (recordId) => {
        try {
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/deletedatameasurer/${recordId}`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });

            setAdditionalData((prevData) => ({
                ...prevData,
                records: prevData.records.filter(record => record._id !== recordId)
            }));
        } catch (error) {
            console.error('Ошибка при удалении записи:', error);
        }
    };

    if (!additionalData) {
        return <div>Загрузка информации...</div>;
    }

    return (
        <div style={{height: '100%'}}>
            <h1>Информация о {additionalData.name}</h1>
            <ul>
                <li>
                    Налоговый код: {additionalData?.taxcode || 'Данные отсутствуют'}
                </li>
                <li>
                    Номер здания: {additionalData.building?.buildingNum || 'Данные отсутствуют'}
                </li>
                <li>
                    Улица: {additionalData.street?.name || 'Данные отсутствуют'}
                </li>
                <li>
                    Город: {additionalData.city?.name || 'Данные отсутствуют'}
                </li>
            </ul>
            <Button className="mt-6" onClick={() => handleUpdateOSBB(additionalData.name, additionalData.taxcode, additionalData.building.buildingNum, additionalData.street.name, additionalData.city.name)} variant="gradient" color="blue">
                Обновить
            </Button>
        </div>
    );
};

export default OSBBDetails;
