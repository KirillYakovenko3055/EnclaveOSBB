import React, { useState } from 'react';
import axios from 'axios';

const SubmitMeasurers = () => {
    const [waterData, setWaterData] = useState({
        number: '',
        currentReading: '',
        previousReading: '',
        hotWater: '',
        date: '',
    });

    const [gasData, setGasData] = useState({
        number: '',
        currentReading: '',
        previousReading: ''
    });

    const [electricityData, setElectricityData] = useState({
        number: '',
        currentReading: '',
        previousReading: ''
    });

    const token = localStorage.getItem('token');

    // Обработка изменения полей для воды
    const handleWaterChange = (e) => {
        setWaterData({ ...waterData, [e.target.name]: e.target.value });
    };

    // Обработка изменения полей для газа
    const handleGasChange = (e) => {
        setGasData({ ...gasData, [e.target.name]: e.target.value });
    };

    // Обработка изменения полей для электроэнергии
    const handleElectricityChange = (e) => {
        setElectricityData({ ...electricityData, [e.target.name]: e.target.value });
    };

    // Проверка на заполненность всех полей для каждой секции
    const isWaterValid = Object.values(waterData).every(field => field !== '');
    const isGasValid = Object.values(gasData).every(field => field !== '');
    const isElectricityValid = Object.values(electricityData).every(field => field !== '');

    // Отправка данных для воды
    const submitWaterData = async () => {
        try {
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/insertdatameasurer/${accountId}`, waterData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert('Показания воды отправлены!');
        } catch (error) {
            console.error('Ошибка отправки показаний воды:', error);
        }
    };

    // Отправка данных для газа
    const submitGasData = async () => {
        try {
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/insertdatameasurer/${accountId}`, gasData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert('Показания газа отправлены!');
        } catch (error) {
            console.error('Ошибка отправки показаний газа:', error);
        }
    };

    // Отправка данных для электроэнергии
    const submitElectricityData = async () => {
        try {
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/insertdatameasurer/${accountId}`, electricityData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            alert('Показания электроэнергии отправлены!');
        } catch (error) {
            console.error('Ошибка отправки показаний электроэнергии:', error);
        }
    };

    return (
        <div className="container mx-auto">
            <h1 className="text-2xl font-bold mb-4">Отправка показаний по счетчикам</h1>

            {/* Вода */}
            <div className="mb-6 p-4 border rounded-lg">
                <h2 className="text-xl font-bold mb-2">Вода</h2>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Номер счетчика</label>
                    <input
                        type="text"
                        name="number"
                        value={waterData.number}
                        onChange={handleWaterChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Текущие показания</label>
                    <input
                        type="number"
                        name="currentReading"
                        value={waterData.currentReading}
                        onChange={handleWaterChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Предыдущие показания</label>
                    <input
                        type="number"
                        name="previousReading"
                        value={waterData.previousReading}
                        onChange={handleWaterChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Количество теплой воды</label>
                    <input
                        type="number"
                        name="hotWater"
                        value={waterData.hotWater}
                        onChange={handleWaterChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Дата</label>
                    <input
                        type="date"
                        name="date"
                        value={waterData.date}
                        onChange={handleWaterChange}
                        className="border p-2 w-full"
                    />
                </div>
                <button
                    disabled={!isWaterValid}
                    onClick={submitWaterData}
                    className={`py-2 px-4 text-white ${isWaterValid ? 'bg-blue-500' : 'bg-gray-400'} rounded-lg`}
                >
                    Отправить
                </button>
            </div>

            {/* Газ */}
            <div className="mb-6 p-4 border rounded-lg">
                <h2 className="text-xl font-bold mb-2">Газ</h2>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Номер счетчика</label>
                    <input
                        type="text"
                        name="number"
                        value={gasData.number}
                        onChange={handleGasChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Текущие показания</label>
                    <input
                        type="number"
                        name="currentReading"
                        value={gasData.currentReading}
                        onChange={handleGasChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Предыдущие показания</label>
                    <input
                        type="number"
                        name="previousReading"
                        value={gasData.previousReading}
                        onChange={handleGasChange}
                        className="border p-2 w-full"
                    />
                </div>
                <button
                    disabled={!isGasValid}
                    onClick={submitGasData}
                    className={`py-2 px-4 text-white ${isGasValid ? 'bg-blue-500' : 'bg-gray-400'} rounded-lg`}
                >
                    Отправить
                </button>
            </div>

            {/* Электроэнергия */}
            <div className="mb-6 p-4 border rounded-lg">
                <h2 className="text-xl font-bold mb-2">Электроэнергия</h2>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Номер счетчика</label>
                    <input
                        type="text"
                        name="number"
                        value={electricityData.number}
                        onChange={handleElectricityChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Текущие показания</label>
                    <input
                        type="number"
                        name="currentReading"
                        value={electricityData.currentReading}
                        onChange={handleElectricityChange}
                        className="border p-2 w-full"
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-gray-700 mb-2">Предыдущие показания</label>
                    <input
                        type="number"
                        name="previousReading"
                        value={electricityData.previousReading}
                        onChange={handleElectricityChange}
                        className="border p-2 w-full"
                    />
                </div>
                <button
                    disabled={!isElectricityValid}
                    onClick={submitElectricityData}
                    className={`py-2 px-4 text-white ${isElectricityValid ? 'bg-blue-500' : 'bg-gray-400'} rounded-lg`}
                >
                    Отправить
                </button>
            </div>
        </div>
    );
};

export default SubmitMeasurers;
