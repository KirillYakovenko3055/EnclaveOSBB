import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Button } from "@material-tailwind/react";

const OSBBDetails = () => {
    const token = localStorage.getItem('token');
    const OSBBId = localStorage.getItem('OSBBId');
    const [additionalData, setAdditionalData] = useState(null);
    const navigate = useNavigate();
    const [apartments, setApartments] = useState([]);

    useEffect(() => {
        const fetchOSBBDetails = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/osbbdetails/${OSBBId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                localStorage.setItem('OSBBId', OSBBId);
                setAdditionalData(response.data);
            } catch (error) {
                console.error('Ошибка получения данных по счету:', error);
            }
        };

        const fetchApartments = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/getApartments/${OSBBId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setApartments(response.data);
            } catch (error) {
                console.error('Ошибка при получении квартир:', error);
            }
        };

        fetchApartments();
        fetchOSBBDetails();
    }, [OSBBId, token]);

    const handleUpdateOSBB = (name, taxcode, buildingNum, streetname, cityname) => {
        if (additionalData?.name && additionalData?.building && additionalData?.street && additionalData?.city) {
            localStorage.setItem("OSBBId", OSBBId);
            localStorage.setItem("BuildingId", additionalData.building._id);
            localStorage.setItem("StreetId", additionalData.street._id);
            localStorage.setItem("CityId", additionalData.city._id);
            navigate('/admin/add-OSBB-data', {
                state: { name: name, taxcode: taxcode, buildingNum: buildingNum, streetname: streetname, cityname: cityname }
            });
        } else {
            console.error("One of the required fields is missing.");
        }
    };

    const handleDeleteRecord = async (recordId) => {
        try {
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/deletedatameasurer/${recordId}`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });

            setAdditionalData((prevData) => ({
                ...prevData,
                records: prevData.records.filter(record => record._id !== recordId)
            }));
        } catch (error) {
            console.error('Ошибка при удалении записи:', error);
        }
    };

    const handleApartmentClick = (personalAccountId) => {
        navigate(`/admin/personal-account/${personalAccountId}`);
    };

    if (!additionalData) {
        return <div>Загрузка информации...</div>;
    }

    return (
        <div style={{ height: '100%' }}>
            <h1>Информация о {additionalData.name}</h1>
            <ul>
                <li>Налоговый код: {additionalData?.taxcode || 'Данные отсутствуют'}</li>
                <li>Номер здания: {additionalData.building?.buildingNum || 'Данные отсутствуют'}</li>
                <li>Улица: {additionalData.street?.name || 'Данные отсутствуют'}</li>
                <li>Город: {additionalData.city?.name || 'Данные отсутствуют'}</li>
            </ul>
            <Button
                className="mt-6"
                onClick={() => handleUpdateOSBB(additionalData.name, additionalData.taxcode, additionalData.building.buildingNum, additionalData.street.name, additionalData.city.name)}
                variant="gradient"
                color="blue"
            >
                Обновить
            </Button>

            {apartments ? (
                <div>
                    <h1>Список квартир в здании: </h1>
                    <ul>
                        {apartments.map((apartment) => (
                            <li 
                                key={apartment.id} 
                                onClick={() => handleApartmentClick(apartment._id)} 
                                style={{ cursor: 'pointer' }}
                            >
                                Квартира №{apartment.flatNum}, Общая площадь: {apartment.totalArea}, Отапливаемая площадь: {apartment.heatingArea}
                            </li>
                        ))}
                    </ul>
                </div>
            ) : (
                <div>
                    <h1>Квартир в здании нет</h1>
                </div>
            )}

            <Button
                className="mt-6"
                onClick={() => navigate('/admin/add-personal-account', { state: { OSBBId } })}
                variant="gradient"
                color="blue"
            >
                Добавить квартиру
            </Button>
        </div>
    );
};

export default OSBBDetails;
