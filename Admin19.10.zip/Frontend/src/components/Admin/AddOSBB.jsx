import React, { useState, useEffect } from 'react';
import { Input, Button, Typography } from "@material-tailwind/react";
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';

const AddMeasurerValue = () => {
    const token = localStorage.getItem('token');
    const location = useLocation();
    const navigate = useNavigate();
    const { name, taxcode, buildingNum, streetname, cityname } = location.state || {};
    const OSBBId = localStorage.getItem('OSBBId');
    const BuildingId = localStorage.getItem('BuildingId');
    const StreetId = localStorage.getItem('StreetId');
    const CityId = localStorage.getItem('CityId');

    const [formData, setFormData] = useState({
        name: '',
        taxcode: '',
        buildingNum: '',
        streetname: '',
        cityname: ''
    });


    useEffect(() => {
        if (name) {
            setFormData({
                name: name, 
                taxcode: taxcode,
                buildingNum: buildingNum, 
                streetname: streetname,
                cityname: cityname, 
            });
        } else {
            setFormData({
                name: '',
                taxcode: '',
                buildingNum: '',
                streetname: '',
                cityname: ''
            });
        }
    }, [name, taxcode, buildingNum, streetname, cityname]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (!name) {
                console.log(12);
                const response = await axios.post(
                    `${import.meta.env.VITE_BACKEND_URL}/api/user/insertdataosbb`,
                    {
                        name: formData.name,
                        taxcode: formData.taxcode,
                        buildingNum: formData.buildingNum,
                        streetname: formData.streetname,
                        cityname: formData.cityname,
                    },
                    {
                        headers: { Authorization: `Bearer ${token}` }
                    }
                );
                navigate(`/admin`, { state: { OSBBId: OSBBId } });
            } else {
                const response = await axios.post(
                    `${import.meta.env.VITE_BACKEND_URL}/api/user/updatedataosbb/${OSBBId}/${BuildingId}/${StreetId}/${CityId}`,
                    {
                        name: formData.name,
                        taxcode: formData.taxcode,
                        buildingNum: formData.buildingNum,
                        streetname: formData.streetname,
                        cityname: formData.cityname,
                    },
                    {
                        headers: { Authorization: `Bearer ${token}` }
                    }
                );
                navigate(`/admin/${OSBBId}`);
            }
        } catch (error) {
            console.error('Ошибка отправки данных:', error.response?.data || error);
        }
    };

    return (
        <div className="container mx-auto flex flex-col items-center justify-center min-h-screen bg-gray-100 p-6">
            <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-md">
                <Typography variant="h4" color="blue" className="text-center mb-6">
                    Данные о ОСББ
                </Typography>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <Typography variant="small" color="gray" className="mb-2">
                            Название ОСББ
                        </Typography>
                        <Input
                            type="text"
                            name="name" 
                            value={formData.name}
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
                            placeholder='Название'
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <Typography variant="small" color="gray" className="mb-2">
                            Налоговый код
                        </Typography>
                        <Input
                            type="text"
                            name="taxcode"
                            value={formData.taxcode} 
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
                            placeholder="Код"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <Typography variant="small" color="gray" className="mb-2">
                            Номер постройки
                        </Typography>
                        <Input
                            type="text"
                            name="buildingNum"
                            value={formData.buildingNum} 
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
                            placeholder="Номер"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <Typography variant="small" color="gray" className="mb-2">
                            Улица
                        </Typography>
                        <Input
                            type="text"
                            name="streetname"
                            value={formData.streetname} 
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
                            placeholder="Название"
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <Typography variant="small" color="gray" className="mb-2">
                            Город
                        </Typography>
                        <Input
                            type="text"
                            name="cityname"
                            value={formData.cityname} 
                            onChange={handleChange}
                            className="w-full border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 p-2"
                            placeholder="Название"
                            required
                        />
                    </div>
                    <Button type="submit" fullWidth variant="gradient" color="blue">
                        {name ? "Обновить" : "Внести"}
                    </Button>
                </form>
            </div>
        </div>
    );
};

export default AddMeasurerValue;
