import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import logo from '../../assets/images/logo_png.png';
import axios from "axios";
import './Main.css';
import {
  Menu,
  MenuHandler,
  MenuList,
  MenuItem,
  Avatar,
  Button,
  Typography,
  IconButton,
  Collapse,
  Navbar,
} from "@material-tailwind/react";
import {
  ChevronDownIcon,
  BellIcon,
  ChatBubbleLeftEllipsisIcon,
} from "@heroicons/react/24/solid";

function ProfileMenu({ userName, handleLogout }) {
  return (
    <div className="flex flex-col items-center">
      <Button variant="text" color="blue-gray" className="flex items-center w-70 font-thin text-base bg-[#A1C060]" style={{ height: "50px", fontFamily: "Arsenal" }}>
        <Link to="/user/profile">
          <Typography className="p-3 text-black" style={{ fontFamily: "Arsenal" }}>
            {userName || " "}
          </Typography>
        </Link>
      </Button>
      <Button
        variant="text"
        color="red"
        className="mt-2"
        onClick={handleLogout}
      >
        Вийти
      </Button>
    </div>
  );
}

const navListItems = [
  { label: "ПРО ПРОЕКТ", path: "/about" },
  { label: "FAQ", path: "/FAQ" },
  { label: "ФОНДИ", path: "/funds" },
];

function LanguageMenu() {
  const [language, setLanguage] = useState("UKR");

  const handleLanguageChange = (lang) => {
    setLanguage(lang);
  };

  return (
    <div className="flex items-center gap-4 ">
      <Menu>
        <MenuHandler>
          <Button variant="text" color="blue-gray" className="flex items-center gap-1">
            <span className="text-black text-sm font-bold">{language}</span>
            <ChevronDownIcon className="h-4 w-4 text-black" />
          </Button>
        </MenuHandler>
        <MenuList>
          <MenuItem onClick={() => handleLanguageChange("UKR")}>Українська</MenuItem>
          <MenuItem onClick={() => handleLanguageChange("ENG")}>English</MenuItem>
          <MenuItem onClick={() => handleLanguageChange("RUS")}>Русский</MenuItem>
        </MenuList>
      </Menu>
      <IconButton size="sm" color="blue-gray" variant="text">
        <ChatBubbleLeftEllipsisIcon className="h-5 w-5 text-gray-900" />
      </IconButton>
      <IconButton size="sm" color="blue-gray" variant="text">
        <BellIcon className="h-5 w-5 fill-current text-gray-900" />
      </IconButton>

      <Button variant="text" color="blue-gray" className="flex items-center w-70 font-thin text-base bg-[#A1C060]" style={{ height: "50px", fontFamily: "Arsenal" }}>
        <Link to="/user/profile">
          Особистий кабінет
        </Link>
      </Button>
    </div>
  );
}

function NavList({ isLoggedIn, handleLoginClick, userName, handleLogout }) {
  return (
    <ul className="flex gap-8 items-center">
      {navListItems.slice(0, 3).map(({ label, path }) => (
        <li key={label} className="text-black">
          <Link to={path}>
            {label}
          </Link>
        </li>
      ))}

      {isLoggedIn ? (
        <ProfileMenu userName={userName} handleLogout={handleLogout} />
      ) : (
        <Button 
          className="bg-[#504E76] text-white w-60 text-center font-bold text-base" 
          size="sm" 
          style={{ fontFamily: 'Philosopher' }} 
          onClick={handleLoginClick}
        >
          ВХІД В КАБІНЕТ
        </Button>
      )}

      {navListItems.slice(3).map(({ label, path }) => (
        <li key={label} className="text-black">
          <Link to={path}>
            {label}
          </Link>
        </li>
      ))}
    </ul>
  );
}

export function ComplexNavbar() {
  const [isNavOpen, setIsNavOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState("");
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const login = localStorage.getItem('login');
  const toggleIsNavOpen = () => setIsNavOpen((cur) => !cur);

  useEffect(() => {
    const checkToken = async () => {
      if (!token) {
        setIsLoggedIn(false);
        return;
      }
      try {
        const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/auth/check-token`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        if (response.data.valid) {
          setIsLoggedIn(true);
          const userResponse = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/me/${login}`, {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          const { firstname, middlename } = userResponse.data.person;
          const formattedUsername = `${firstname} ${middlename}`;

          setUserName(formattedUsername);
        } else {
          localStorage.removeItem("accountId");
          localStorage.removeItem("token");
          setIsLoggedIn(false);
        }
      } catch (error) {
        setIsLoggedIn(false);
      }
    };

    checkToken();
  }, [token]);

  const handleLoginClick = () => {
    navigate("/login");
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("accountId");
    setIsLoggedIn(false);
    navigate("/login");
  };

  return (
    <Navbar className="mx-auto" style={{ maxWidth: "2000px" }}>
      <div className="relative mx-auto flex items-center justify-between text-blue-gray-900">

        <Link to="/" className="ml-10">
          <img style={{ width: "8rem"}} src={logo}></img>
        </Link>

        <div className="hidden lg:block">
          <NavList isLoggedIn={isLoggedIn} handleLoginClick={handleLoginClick} userName={userName} handleLogout={handleLogout} />
        </div>

        <LanguageMenu />
      </div>

      <Collapse open={isNavOpen} className="overflow-scroll">
        <NavList isLoggedIn={isLoggedIn} handleLoginClick={handleLoginClick} handleLogout={handleLogout} />
      </Collapse>
    </Navbar>
  );
}

export default ComplexNavbar;
