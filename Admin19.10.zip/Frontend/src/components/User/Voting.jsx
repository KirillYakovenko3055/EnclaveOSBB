import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Card, Button, Typography, Radio } from "@material-tailwind/react";

const Voting = () => {
    const token = localStorage.getItem('token');
    const accountId = localStorage.getItem('accountId');
    const votingId = localStorage.getItem("votingId");
    const navigate = useNavigate();
    const [additionalData, setAdditionalData] = useState(null);
    const [answers, setAnswers] = useState({});
    const [questions, setQuestions] = useState([]);
    useEffect(() => {
        const fetchVotingData = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/questions/${votingId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setAdditionalData(response.data);

                const answersResponse = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/votingresults/${accountId}/${votingId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const userPreviousAnswers = answersResponse.data.answers;

                const formattedAnswers = {};
                userPreviousAnswers.forEach(answer => {
                    const result = answer.result?.toString('base64'); 
                    formattedAnswers[answer.questionId] = result === 'AQ==' ? true : result === 'AA==' ? false : null;
                });
                setQuestions(response.data.questions);
                setAnswers(formattedAnswers);
            } catch (error) {
                console.error('Ошибка получения данных о голосовании или ответах:', error);
            }
        };

        fetchVotingData();
    }, [votingId, token, accountId]);

    const handleAnswerChange = (questionId, value) => {
        setAnswers({
            ...answers,
            [questionId]: value
        });
    };

    const handleSubmit = async () => {
        try {
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/submit/${accountId}`, {
                votingId,
                answers: answers
            }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            navigate(`/user/votings/${accountId}`);
        } catch (error) {
            console.error('Ошибка при отправке результатов голосования:', error);
        }
    };

    if (!additionalData) {
        return <div>Загрузка информации...</div>;
    }

    return (
        <div style={{ height: '100%' }}>
            <h1>{additionalData.voting.title}</h1>
            <ul>
                {questions.map(question => (
                    <li key={question._id} style={{ marginBottom: '20px' }}>
                        <Typography variant="h6">{question.content}</Typography>

                        <div>
                        <Radio
                                name={`question_${question._id}`}
                                label="Да"
                                checked={answers[question._id] === true}
                                onChange={() => handleAnswerChange(question._id, true)}
                            />
                            <Radio
                                name={`question_${question._id}`}
                                label="Нет"
                                checked={answers[question._id] === false} 
                                onChange={() => handleAnswerChange(question._id, false)}
                            />
                        </div>
                    </li>
                ))}
            </ul>

            <Button className="mt-6" onClick={handleSubmit} variant="gradient" color="blue">
                Отправить результаты
            </Button>
        </div>
    );
};

export default Voting;
