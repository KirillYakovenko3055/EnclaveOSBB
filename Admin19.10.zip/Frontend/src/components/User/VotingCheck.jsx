import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Button, Typography, Dialog, DialogHeader, DialogBody, DialogFooter } from "@material-tailwind/react";

const VotingCheck = () => {
    const token = localStorage.getItem('token');
    const votingId = localStorage.getItem("votingId");
    const [votingData, setVotingData] = useState(null);
    const [selectedParticipant, setSelectedParticipant] = useState(null);
    const [isDialogOpen, setIsDialogOpen] = useState(false);

    useEffect(() => {
        const fetchVotingData = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/votingcheck/${votingId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setVotingData(response.data);
            } catch (error) {
                console.error('Ошибка получения данных о голосовании или ответах:', error);
            }
        };

        fetchVotingData();
    }, [votingId, token]);

    const handleParticipantClick = (participant) => {
        setSelectedParticipant(participant);
        setIsDialogOpen(true);
    };

    const handleCloseDialog = () => {
        setIsDialogOpen(false);
        setSelectedParticipant(null);
    };

    if (!votingData) {
        return <div>Загрузка информации...</div>;
    }

    return (
        <div style={{ height: '100%' }}>
            <Typography variant="h4" color="blue-gray" className="text-center mb-6">
                Результаты голосования
            </Typography>

            {Object.entries(votingData.voteStats).map(([questionId, voteInfo], index) => (
                <Card key={questionId} className="mb-6 p-6">
                    <Typography variant="h5" color="blue-gray" className="mb-4">
                        Вопрос {index + 1}: {voteInfo.question}
                    </Typography>
                    <Typography>
                        Позитивных ответов: {voteInfo.yesVotes}
                    </Typography>
                    <Typography>
                        Негативных ответов: {voteInfo.noVotes}
                    </Typography>
                    <Typography>
                        Воздержались: {voteInfo.abstainedVotes}
                    </Typography>
                </Card>
            ))}

            <Typography variant="h5" color="blue-gray" className="mt-8 mb-4">
                Участники голосования:
            </Typography>
            <div>
                {votingData.participants.map((participant) => (
                    <Button
                        key={participant._id}
                        onClick={() => handleParticipantClick(participant)} 
                        className="mr-2 mb-2"
                        variant="outlined"
                        color="blue"
                    >
                        {participant.lastname} {participant.firstname} {participant.middlename}
                    </Button>
                ))}
            </div>

            {selectedParticipant && (
                <Dialog open={isDialogOpen} handler={handleCloseDialog}>
                    <DialogHeader>
                        Ответы участника: {selectedParticipant.lastname} {selectedParticipant.firstname} {selectedParticipant.middlename}
                    </DialogHeader>
                    <DialogBody divider>
                        {Object.entries(selectedParticipant.answers).map(([questionId, answer], idx) => (
                            <div key={questionId}>
                                <Typography variant="h6">Вопрос {idx + 1}: {votingData.voteStats[questionId]?.question}</Typography>
                                <Typography>Ответ: {answer === null ? 'Воздержался' : answer ? 'Да' : 'Нет'}</Typography>
                                <hr className="my-2" />
                            </div>
                        ))}
                    </DialogBody>
                    <DialogFooter>
                        <Button variant="text" color="red" onClick={handleCloseDialog}>
                            Закрыть
                        </Button>
                    </DialogFooter>
                </Dialog>
            )}

            <Button className="mt-6" variant="gradient" color="blue">
                Назад к голосованиям
            </Button>
        </div>
    );
};

export default VotingCheck;