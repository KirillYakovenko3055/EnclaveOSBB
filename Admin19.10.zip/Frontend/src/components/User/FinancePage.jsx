import React from 'react';
import { Link } from 'react-router-dom';
import './Profile.css'
import finance1 from '../../assets/images/finance1.png';
import finance2 from '../../assets/images/finance2.png';
import finance3 from '../../assets/images/finance3.png';
import finance4 from '../../assets/images/finance4.png';
import finance5 from '../../assets/images/finance5.png';

const FinanceGrid = () => {
    return (
        <div>
            <div className="flex items-center ml-10 mt-5">
                <Link className='text-base text-gray-500' size='sm' style={{ fontFamily: 'Arsenal' }} to={'/'}>
                    Головна&nbsp;&nbsp;{'>'}&nbsp;&nbsp;
                </Link>
                <Link className='underline text-base text-gray-500' size='sm' style={{ fontFamily: 'Arsenal' }}>
                    Фінанси
                </Link>
            </div>
            <div className="p-10">
                <h1 className="text-4xl font-bold mb-12 text-center" style={{ fontFamily: 'Philosopher' }}>ФІНАНСИ</h1>
                <div className='flex'>
                    {/* First column with overlay text */}
                    <div className="relative first">
                        <img src={finance1} alt="Finance 1" className="w-full h-full object-cover" />
                        <div className="overlay-text">Заборгованність</div>
                    </div>
                    {/* Second column with two images */}
                    <div>
                        <div className="relative second">
                            <img src={finance2} alt="Finance 2" className="w-full h-full object-cover" />
                        </div>
                        <div className="relative third">
                            <img src={finance3} alt="Finance 3" className="w-full h-full object-cover" />
                        </div>
                    </div>
                    {/* Third column with two images */}
                    <div>
                        <div className="relative fourth">
                            <img src={finance4} alt="Finance 4" className="w-full h-full object-cover" />
                        </div>
                        <div className="relative fifth">
                            <img src={finance5} alt="Finance 5" className="w-full h-full object-cover" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FinanceGrid;