import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import {
    Button,
    Typography,
} from "@material-tailwind/react";

const Measurers = () => {
    const [measurers, setMeasurers] = useState([]);
    const token = localStorage.getItem('token');
    const accountId = localStorage.getItem('accountId');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchMeasurers = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/measurers/${accountId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setMeasurers(response.data.measurers);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchMeasurers();
    }, []);

    const handleMeasurerClick = async (measurerId) => {
        try {
            localStorage.setItem("measurerId", measurerId);
            navigate(`/user/measurer/${measurerId}`);
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };

    return (
        <div className="card container mx-auto px-4 rounded-3xl">
            <div className="about-section">
                <Typography variant='h1' style={{ color: '#A3B565' }}>Список счетчиков</Typography>
                <Typography variant='h2' style={{ color: '#002000' }}>Ваши счетчики:</Typography>
            </div>
            <div className="holder">
                {measurers.map(measurer => (
                    <div className="cont mx-auto px-4 rounded-3xl">
                        <div className="container">
                            <Typography variant='h4' key={measurer._id} onClick={() => handleMeasurerClick(measurer._id)}>
                                {measurer.number}
                            </Typography>
                        </div>
                    </div>
                ))}

            </div>
        </div>

    );
};

export default Measurers;