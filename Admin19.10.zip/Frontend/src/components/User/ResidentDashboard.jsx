import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "../OSBB/OSBB.css"
import "../Main/Main.css"
import {
    Button,
    Typography,
} from "@material-tailwind/react";


const ResidentDashboard = () => {
    const [accounts, setAccounts] = useState([]);
    const [residentName, setResidentName] = useState([]);
    const token = localStorage.getItem('token');
    const login = localStorage.getItem('login');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchAccounts = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/accounts/${login}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setAccounts(response.data.accounts);
                setResidentName(response.data.person[0].firstname)
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchAccounts();
    }, []);

    const handleAccountClick = async (accountId) => {
        try {
            const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/account/${accountId}`, {
                headers: { Authorization: `Bearer ${token}` }
            });

            navigate(`/user/account/${accountId}`, { state: { accountData: response.data } });
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };
    return (
        <div className="card container mx-auto px-4 rounded-3xl">
            <div className="about-section">
                <Typography variant='h1' style={{ color: '#A3B565' }}>Добро пожаловать {residentName}!</Typography>
                <Typography variant='h2' style={{ color: '#002000' }}>Ваши счета:</Typography>
            </div>
            <div className="holder">
                {accounts.map(account => (
                    <div className="cont mx-auto px-4 rounded-3xl">
                        <div className="container">
                            <Typography variant='h4' key={account._id} onClick={() => handleAccountClick(account._id)}>
                                {account.personalNumber}
                            </Typography>
                        </div>
                    </div>
                ))}

            </div>
        </div>
    );
};
export default ResidentDashboard;