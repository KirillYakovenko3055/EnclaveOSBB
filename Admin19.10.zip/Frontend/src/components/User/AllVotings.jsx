import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Card, Button, Typography } from "@material-tailwind/react";

const AllVotings = () => {
    const [votings, setVotings] = useState([]);
    const token = localStorage.getItem('token');
    const accountId = localStorage.getItem('accountId');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchVotings = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/votings/${accountId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setVotings(response.data);
            } catch (error) {
                console.error('Ошибка получения голосований:', error);
            }
        };

        fetchVotings();
    }, [token, accountId]);

    const handleVotingClick = async (votingId) => {
        localStorage.setItem("votingId", votingId);
        navigate(`/user/voting/${votingId}`);
    }

    const handleCheckClick = async (votingId) => {
        localStorage.setItem("votingId", votingId);
        navigate(`/admin/votingcheck/${votingId}`);
    }

    const handleDeleteClick = async (votingId) => {
        try {
            console.log(votingId);
            await axios.delete(`${import.meta.env.VITE_BACKEND_URL}/api/user/votings/${votingId}`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setVotings(votings.filter(voting => voting._id !== votingId));
        } catch (error) {
            console.error('Ошибка при удалении голосования:', error);
        }
    }

    return (

        <div className="card container mx-auto px-4 rounded-3xl">
            <div className="about-section">
                <Typography variant='h1' style={{ color: '#A3B565' }}>Голосования</Typography>
            </div>
            <div className="holder">
                {votings.map(voting => (
                    <div className="cont mx-auto px-4 rounded-3xl">
                        <div className="container">
                            <li key={voting._id} classNameName="mb-4 p-4 border rounded-lg shadow">
                                <div>Название: {voting.title}</div>
                                <div classNameName="flex justify-between items-center mt-2">
                                    <div onClick={() => handleVotingClick(voting._id)}>
                                        Начало: {new Date(voting.startDate).toLocaleString()} Конец: {new Date(voting.endDate).toLocaleString()}
                                    </div>
                                    <div>
                                        <Button classNameName="ml-4" onClick={() => handleCheckClick(voting._id)} variant="gradient" color="green">
                                            Проверить Результаты
                                        </Button>
                                        <Button
                                            classNameName="ml-4"
                                            onClick={() => handleDeleteClick(voting._id)}
                                            variant="outlined"
                                            color="red"
                                        >
                                            Удалить
                                        </Button>
                                    </div>
                                </div>
                            </li>
                        </div>
                    </div>
                ))}

            </div>
        </div>
    );
};

export default AllVotings;