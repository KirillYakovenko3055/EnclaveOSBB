import React, { useState } from 'react';
import axios from 'axios';
import { Card, Button, Input, Typography } from "@material-tailwind/react";

const CreateVoting = () => {
    const [title, setTitle] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [questions, setQuestions] = useState([{ text: '' }]); 
    const OSBBId = localStorage.getItem("OSBBId");
    const token = localStorage.getItem("token");

    const handleQuestionChange = (index, event) => {
        const newQuestions = [...questions];
        newQuestions[index].text = event.target.value;
        setQuestions(newQuestions);
    };

    const handleAddQuestion = () => {
        setQuestions([...questions, { text: '' }]);
    };

    const handleRemoveQuestion = (index) => {
        const newQuestions = questions.filter((_, i) => i !== index); 
        setQuestions(newQuestions);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const votingData = {
            title,
            startDate,
            endDate,
            questions: questions.map(q => ({ text: q.text }))
        };

        try {
            console.log(OSBBId);
            await axios.post(`${import.meta.env.VITE_BACKEND_URL}/api/user/votingcreate/${OSBBId}`, votingData, {
                headers: { Authorization: `Bearer ${token}` }
            });
            setTitle('');
            setStartDate('');
            setEndDate('');
            setQuestions([{ text: '' }]);
        } catch (error) {
            console.error('Ошибка при создании голосования:', error);
        }
    };

    return (
        <div className="max-w-md mx-auto mt-10">
            <Card className="p-6">
                <Typography variant="h4" color="blue-gray" className="text-center mb-6">
                    Создать новое голосование
                </Typography>
                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <Input
                            type="text"
                            label="Название"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <Input
                            type="date"
                            label="Дата начала"
                            value={startDate}
                            onChange={(e) => setStartDate(e.target.value)}
                            required
                        />
                    </div>
                    <div className="mb-4">
                        <Input
                            type="date"
                            label="Дата окончания"
                            value={endDate}
                            onChange={(e) => setEndDate(e.target.value)}
                            required
                        />
                    </div>
                    <Typography variant="h5" className="mb-4">
                        Вопросы:
                    </Typography>
                    {questions.map((question, index) => (
                        <div key={index} className="flex mb-4">
                            <Input
                                type="text"
                                value={question.text}
                                onChange={(e) => handleQuestionChange(index, e)}
                                placeholder={`Вопрос ${index + 1}`}
                                required
                                className="mr-2"
                            />
                            <Button 
                                color="red" 
                                onClick={() => handleRemoveQuestion(index)} 
                                variant="outlined"
                                className="self-end"
                            >
                                Удалить
                            </Button>
                        </div>
                    ))}
                    <Button 
                        color="blue" 
                        onClick={handleAddQuestion} 
                        variant="outlined" 
                        className="mb-4"
                    >
                        Добавить вопрос
                    </Button>
                    <Button type="submit" variant="gradient" color="green">
                        Создать голосование
                    </Button>
                </form>
            </Card>
        </div>
    );
};

export default CreateVoting;
