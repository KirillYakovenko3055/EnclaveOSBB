import React, { Component } from 'react';
import "./OSBB.css"
import "../Main/Main.css"
import { Typography } from '@material-tailwind/react';
export default class EditUser extends Component {
constructor(props){
    super(props);

    this.state={
    };
}

render() {
    return (
        <div className="container mx-auto px-4 rounded-3xl bSty heightTo backimgAboutUs centered">
            <div className="about-section">
                <Typography variant='h1' style={{color:"#A3B565"}}>Наша Организация</Typography>
            </div>
            <div className="holder">
                <div className="card cont mx-auto px-4 rounded-3xl">
                <img className="imgProf" src='' alt=""/>
                <div className="container">
                    <Typography style={{color:"#A3B565"}} variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            <div className="card cont mx-auto px-4 rounded-3xl">
                <img className="imgProf" src='' alt=""/>
                <div className="container">
                    <Typography style={{color:"#A3B565"}} variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            </div>
            <div className="holder">
                <div className="card cont mx-auto px-4 rounded-3xl">
                <img className="imgProf" src='' alt=""/>
                <div className="container">
                    <Typography style={{color:"#A3B565"}} variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            <div className="card cont mx-auto px-4 rounded-3xl">
                <img className="imgProf" src='' alt=""/>
                <div className="container">
                    <Typography style={{color:"#A3B565"}} variant='h4' textGradient>CEO & Founder</Typography>
                    <Typography color='darkgray'>Some text that describes me lorem ipsum ipsum lorem.</Typography>
                </div>
            </div>
            </div>
            
        </div>
    )
    }
}