import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import RegisterForm from './components/Auth/Register';
import LoginForm from './components/Auth/Login';
import VerifyCodeForm from './components/Auth/VerifyCodeForm';

import Navbar from "./components/Main/Header";
import Main from "./components/Main/Main";
import ScrollTop from "./components/Main/ScrollTop";
import Footer from "./components/Main/Footer";

import About from "./components/OSBB/About";
import FAQ from "./components/OSBB/FAQ";

import ResidentDashboard from './components/User/ResidentDashboard'; 
import Error from './components/Error'; 
import PrivateRoute from './components/PrivateRoute';
import Measurers from './components/User/Measurers';
import MeasurerDetails from './components/User/MeasurerDetails';
import AddMeasurerValue from './components/User/AddMeasurerValue'; 
import Services from './components/User/Services'; 
import AccountDetails from './components/User/AccountDetails'; 
import Payments from './components/User/Payments'; 
import OSBBList from "./components/Admin/OSBBList";
import OSBBDetails from "./components/Admin/OSBBDetails";
import AddOSBB from "./components/Admin/AddOSBB";
import AllVotings from "./components/User/AllVotings";
import Voting from "./components/User/Voting";
import VotingCheck from "./components/User/VotingCheck";
import CreateVoting from "./components/User/CreateVoting";
import Profile from "./components/User/Profile"
import ChangeProfile from "./components/User/ChangeProfile";
import FinancePage from "./components/User/FinancePage";
import AddPersonalAccount from "./components/Admin/AddPersonalAccount";
import PersonalAccountDetails from "./components/Admin/PersonalAccountDetails";


import "./index.css";

const App = () => {
  return (
      <div style={{ height: "100%", display:"flex", flexDirection:"column"}}>
    <Router>
      <Navbar/>
      <div style={{ flexGrow:"2",  alignContent:"center"}}>
        <Routes>
          <Route path="/" element={<Main />} />
          <Route path="/register" element={<RegisterForm />} />
          <Route path="/login" element={<LoginForm />} />
          <Route path="*" element={<Error />}></Route>
          <Route path="/about" element={<About />}></Route>
          <Route path="/FAQ" element={<FAQ />}></Route>
          <Route path="/verify" element={<VerifyCodeForm />} />
          <Route path="/user/*" element={<PrivateRoute allowedRoles={['user', 'admin']}>
                <div className="enterD1" style={{ flexGrow:"2",  alignContent:"center"}}>
              <Routes>
                <Route index element={<ResidentDashboard />} />
                <Route path="account/:accountId" element={<AccountDetails />} />
                <Route path="measurers/:accountId" element={<Measurers />} />
                <Route path="measurer/:measurerId" element={<MeasurerDetails />} />
                <Route path="add-measurer-data" element={<AddMeasurerValue />} />
                <Route path="services/:accountId" element={<Services />} />
                <Route path="payments/:accountId" element={<Payments />} />
                <Route path="votings/:accountId" element={<AllVotings />} />
                <Route path="voting/:votingId" element={<Voting />} />
                <Route path="profile" element={<Profile />} />
                <Route path="/update-contact/:type" element={<ChangeProfile />} />
                <Route path="/finances" element={<FinancePage />} />
              </Routes>
                </div>
            </PrivateRoute>} />
            <Route path="/admin/*" element={<PrivateRoute allowedRoles={['admin']}>
              <Routes>
                <Route index element={<OSBBList />} />
                <Route path="/:OSBBId" element={<OSBBDetails />} />
                <Route path="personal-account/:personalAccountId" element={<PersonalAccountDetails />} />
                <Route path="add-personal-account" element={<AddPersonalAccount/>} />
                <Route path="add-OSBB-data" element={<AddOSBB />} />
                <Route path="add-OSBB-data" element={<AddOSBB />} />
                <Route path="createvoting" element={<CreateVoting />} />
                <Route path="votingcheck/:votingId" element={<VotingCheck />} />
              </Routes>
            </PrivateRoute>} />
        </Routes>
        </div>
        <Footer/>
        <ScrollTop/>
    </Router>
        </div>
  );
};

export default App;
