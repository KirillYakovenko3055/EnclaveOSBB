const express = require('express');
const router = express.Router();
const accountController = require('../controllers/accountController');
const measurersController = require('../controllers/measurersController');
const osbbController = require('../controllers/osbbController');
const paymentsController = require('../controllers/paymentsController');
const servicesController = require('../controllers/servicesController');
const votingsController = require('../controllers/votingController');
const profileController = require('../controllers/profileController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/dataformain', osbbController.getData);
router.get('/osbblist', authMiddleware(['admin']), osbbController.getOSBBList);
router.get('/osbbdetails/:OSBBId', authMiddleware(['admin']), osbbController.getOSBBDetails);

router.get('/getApartments/:OSBBId', authMiddleware(['admin']), osbbController.getApartments);
router.post('/addPersonalAccount/:OSBBId', authMiddleware(['admin']), osbbController.addPersonalAccount);

router.post('/updatedataosbb/:OSBBId/:BuildingId/:StreetId/:CityId', authMiddleware(['admin']), osbbController.updateOSBBDetails);
router.post('/deletedataosbb/:OSBBId/:BuildingId/:StreetId/:CityId', authMiddleware(['admin']), osbbController.deleteOSBB);
router.post('/insertdataosbb', authMiddleware(['admin']), osbbController.insertOSBB);
router.get('/accounts/:login', authMiddleware(['user', 'admin']), accountController.getAccounts);
router.get('/account/:accountId', authMiddleware(['user', 'admin']), accountController.getAccount);
router.get('/accountdetails/:accountId', authMiddleware(['user', 'admin']), accountController.getAccountDetails);

router.get('/accountresidentsowners/:accountId', authMiddleware(['user', 'admin']), accountController.getAccountResidentsAndOwners);

router.get('/measurers/:accountId', authMiddleware(['user', 'admin']), measurersController.getMeasurers);
router.get('/measurer/:measurerId', authMiddleware(['user', 'admin']), measurersController.getMeasurerDetails);
router.post('/insertdatameasurer/:measurertopersonalaccountId', authMiddleware(['admin']), measurersController.insertDataMeasurer);
router.post('/deletedatameasurer/:recordId', authMiddleware(['admin']), measurersController.deleteDataMeasurer);
router.post('/updatedatameasurer/:recordId', authMiddleware(['admin']), measurersController.updateDataMeasurer);
router.get('/services/:accountId', authMiddleware(['admin', 'user']), servicesController.getServices);
router.get('/payments/:accountId', authMiddleware(['admin', 'user']), paymentsController.getPayments);
router.get('/votings/:accountId', authMiddleware(['admin', 'user']), votingsController.getVotings);
router.get('/questions/:votingId', authMiddleware(['admin', 'user']), votingsController.getVotingQuestions);
router.post('/submit/:accountId', authMiddleware(['admin', 'user']), votingsController.submitVotingQuestions);
router.get('/votingresults/:accountId/:votingId', authMiddleware(['admin', 'user']), votingsController.getUserVotingResults);
router.get('/votingcheck/:votingId', authMiddleware(['admin', 'user']), votingsController.getAllVotingResults);
router.post('/votingcreate/:OSBBId', authMiddleware(['admin']), votingsController.createVoting);
router.delete('/votings/:votingId', authMiddleware(['admin']), votingsController.deleteVoting);
router.get('/me/:login', authMiddleware(['admin', 'user']), profileController.getProfile);
router.post('/updatecontact/:personId', authMiddleware(['admin', 'user']), profileController.updateContact);

module.exports = router;
