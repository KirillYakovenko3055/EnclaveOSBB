const bcrypt = require('bcryptjs');
const { getDB } = require('../config/db');
const { ObjectId } = require('mongodb');

exports.getOSBBList = async (req, res) => {
    try {
        const db2 = getDB();

        const osbbCollection = db2.collection('osbborganizations');

        const osbbs = await osbbCollection.find({}).toArray();

        res.json(osbbs);
    } catch (error) {
        console.error('Error fetching accounts by accountId:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
};

exports.getOSBBDetails = async (req, res) => {
    const { OSBBId } = req.params;
    try {
        const db2 = getDB();

        const osbbCollection = db2.collection('osbborganizations');
        const buildingsCollection = db2.collection('buildings');
        const cityCollection = db2.collection('cities');
        const streetCollection = db2.collection('streets');

        const osbb = await osbbCollection.findOne({ _id: new ObjectId(OSBBId) });
        const building = await buildingsCollection.findOne({ _id: new ObjectId(osbb.buildingId) });
        const city = await cityCollection.findOne({ _id: building? new ObjectId(building.cityId) : null });
        const street = await streetCollection.findOne({ _id: building ? new ObjectId(building.streetId) : null });

        res.json({
            ...osbb,
            building,
            city,
            street
        });exports.getOSBBDetails = async (req, res) => {
            const { OSBBId } = req.params;
            try {
                const db2 = getDB();
        
                const osbbCollection = db2.collection('osbborganizations');
                const buildingsCollection = db2.collection('buildings');
                const cityCollection = db2.collection('cities');
                const streetCollection = db2.collection('streets');
        
                // Находим OSBB по ID
                const osbb = await osbbCollection.findOne({ _id: new ObjectId(OSBBId) });
                if (!osbb) {
                    return res.status(404).json({ message: 'OSBB not found' });
                }
        
                // Находим здание по buildingId из OSBB
                const building = osbb.buildingId ? await buildingsCollection.findOne({ _id: new ObjectId(osbb.buildingId) }) : null;
                if (!building) {
                    console.warn('Building not found or buildingId is null for OSBB:', OSBBId);
                }
        
                // Находим город по cityId из здания (если здание найдено)
                const city = building?.cityId ? await cityCollection.findOne({ _id: new ObjectId(building.cityId) }) : null;
                if (!city) {
                    console.warn('City not found or cityId is null for building:', building?._id);
                }
        
                // Находим улицу по streetId из здания (если здание найдено)
                const street = building?.streetId ? await streetCollection.findOne({ _id: new ObjectId(building.streetId) }) : null;
                if (!street) {
                    console.warn('Street not found or streetId is null for building:', building?._id);
                }
        
                // Возвращаем данные с учётом того, что некоторые могут быть null
                res.json({
                    ...osbb,
                    building: building || null,
                    city: city || null,
                    street: street || null
                });
            } catch (error) {
                console.error('Error fetching OSBB details:', error);
                return res.status(500).json({ message: 'Internal server error' });
            }
        };
        
    } catch (error) {
        console.error('Error fetching accounts by accountId:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
};

exports.updateOSBBDetails = async (req, res) => {
    const { OSBBId, BuildingId, StreetId, CityId } = req.params;

    try {
        const db2 = getDB();

        const osbbOrganisationsCollection = db2.collection('osbborganizations');
        const buildingsCollection = db2.collection('buildings');
        const citiesCollection = db2.collection('cities');
        const streetsCollection = db2.collection('streets');

        const { name, taxcode, buildingNum, streetname, cityname } = req.body;

        const updatedOsbb = {
            name: name,
            taxcode: taxcode,
        };

        const osbbResult = await osbbOrganisationsCollection.updateOne(
            { _id: new ObjectId(OSBBId) },
            { $set: updatedOsbb }
        );

        const updatedBuilding = {
            buildingNum: buildingNum,
        };

        const buildingResult = await buildingsCollection.updateOne(
            { _id: new ObjectId(BuildingId) },
            { $set: updatedBuilding }
        );

        const updatedCity = {
            name: cityname,
        };

        const cityResult = await citiesCollection.updateOne(
            { _id: new ObjectId(CityId) },
            { $set: updatedCity }
        );

        const updatedStreet = {
            name: streetname,
        };

        const streetResult = await streetsCollection.updateOne(
            { _id: new ObjectId(StreetId) },
            { $set: updatedStreet }
        );

        res.status(200).json({
            message: 'Записи успешно обновлены',
            OSBBId: OSBBId,
        });

    } catch (error) {
        console.error('Ошибка при обновлении записей:', error);
        res.status(500).json({ message: 'Ошибка при обновлении данных' });
    }
};

exports.insertOSBB = async (req, res) => {
    try {
        const db2 = getDB();

        const osbbOrganisationsCollection = db2.collection('osbborganizations');
        const buildingsCollection = db2.collection('buildings');
        const citiesCollection = db2.collection('cities');
        const streetsCollection = db2.collection('streets');

        const { name, taxcode, buildingNum, streetname, cityname } = req.body;

        const newCity = {
            name: cityname,
        };
        const cityResult = await citiesCollection.insertOne(newCity);
        const cityId = cityResult.insertedId;

        const newStreet = {
            name: streetname,
        };
        const streetResult = await streetsCollection.insertOne(newStreet);
        const streetId = streetResult.insertedId;

        const newBuilding = {
            buildingNum: buildingNum,
            cityId: cityId,
            streetId: streetId,
        };
        const buildingResult = await buildingsCollection.insertOne(newBuilding);
        const buildingId = buildingResult.insertedId;

        const newOsbb = {
            name: name,
            taxcode: taxcode,
            buildingId: buildingId,
        };
        const osbbResult = await osbbOrganisationsCollection.insertOne(newOsbb);

        res.status(201).json({
            message: 'Записи успешно добавлены'
        });

    } catch (error) {
        console.error('Ошибка при добавлении записей:', error);
        res.status(500).json({ message: 'Ошибка при добавлении данных' });
    }
};

exports.deleteOSBB = async (req, res) => {

};

exports.getData = async (req, res) => {
    try {
        const db2 = getDB();
        const osbbCount = await db2.collection('osbborganizations').countDocuments();
        const userCount = await db2.collection('users').countDocuments();

        res.json({ count: osbbCount, count2: userCount });
    } catch (error) {
        res.status(500).json({ error: 'Ошибка при получении данных ОСББ.' });
    }
};

exports.getApartments = async (req, res) => {
    //console.log(OSBBId);
    try {
        const { OSBBId } = req.params;

        const db2 = getDB();
        const PersonalAccounts = db2.collection('personalaccounts');

        const apartments = await PersonalAccounts 
            .find({ buildingId: new ObjectId(OSBBId) })
            .toArray();
        console.log(apartments)
        if (!apartments.length) {
            return res.status(404).json({ message: 'Квартиры не найдены' });
        }

        res.status(200).json(apartments);
    } catch (error) {
        console.error('Ошибка при получении квартир:', error);
        res.status(500).json({ message: 'Ошибка при получении данных' });
    }
};
exports.addPersonalAccount = async (req, res) => {
    const { ObjectId } = require('mongodb'); 

        const { OSBBId } = req.params;
        const { flatNum, totalArea, heatingArea, personId, typeId } = req.body;
    
        console.log("Received data:", { flatNum, totalArea, heatingArea, personId, typeId }); 
        console.log("2");
        const personalNumber = `PA-${Math.floor(Math.random() * 1000)}`;
        console.log("2");
        try {
            const db = getDB();
            const personalAccountsCollection = db.collection('personalaccounts');
            const ownersToPersonalAccountsCollection = db.collection('ownerstopersonalaccounts');
    
            const newPersonalAccount = {
                buildingId: new ObjectId(OSBBId),
                flatNum: flatNum,
                totalArea: totalArea,
                heatingArea: heatingArea,
                personId: new ObjectId(personId),
                typeId: new ObjectId(typeId),
                personalNumber: personalNumber,
            };
    
            const personalAccountResult = await personalAccountsCollection.insertOne(newPersonalAccount);
            const personalAccountId = personalAccountResult.insertedId;
    
            console.log(newPersonalAccount);
    
            const ownerToAccountLink = {
                ownerId: new ObjectId(personId),
                personalAccountId: personalAccountId,
            };
    
            await ownersToPersonalAccountsCollection.insertOne(ownerToAccountLink);
    
            res.status(201).json({ message: 'Квартира успешно добавлена и привязана к владельцу', personalNumber });
        } catch (error) {
            console.error('Ошибка при добавлении лицевого счета:', error);
            res.status(500).json({ message: 'Ошибка при добавлении данных о квартире' });
        }
};