const bcrypt = require('bcryptjs');
const { getDB } = require('../config/db');
const { ObjectId } = require('mongodb');
const { use } = require('../routes/auth');

exports.getProfile = async (req, res) => {
    const { login } = req.params;

    try {
      const db2 = getDB();
      const userCollection = db2.collection('users');
      const userToAccountsCollection = db2.collection('userstopersonalaccounts');
      const personalAccountsCollection = db2.collection('personalaccounts');
      const buildingsCollection = db2.collection("buildings");
      const streetsCollection = db2.collection("streets");
      const citiesCollection = db2.collection("cities");
      const personCollection = db2.collection('persons');
  
      const user = await userCollection.findOne({login: login});
      const userToAccounts = await userToAccountsCollection.findOne({userId: new ObjectId(user._id)});
      const account = await personalAccountsCollection.findOne({_id: new ObjectId(userToAccounts.personalAccountId)});
      const building = await buildingsCollection.findOne({_id: new ObjectId(account.buildingId)});
      const street = await streetsCollection.findOne({_id: new ObjectId(building.streetId)});
      const city = await citiesCollection.findOne({_id: new ObjectId(building.cityId)});
      const person = await personCollection.findOne({_id: new ObjectId(account.personId)});
  
      res.json({
        person: person,
        account: account,
        street: street,
        city: city
    });

    } catch (error) {
      console.error('Error fetching accounts by accountId:', error);
      return res.status(500).json({ message: 'Internal server error' });
    }
  };

  exports.updateContact = async (req, res) => {
    const { personId } = req.params;
    const { data } = req.body;

    try {
        const db2 = getDB();
        const personCollection = db2.collection('persons');

        const person = await personCollection.findOne({ _id: new ObjectId(personId) });

        if (!person) {
            return res.status(404).json({ message: 'Person not found' });
        }

        let updateField = {};
        if (data.includes('@')) {
            updateField = { email: data };
        } else if (data.startsWith('+')) {
            updateField = { phone: data };
        } else {
            return res.status(400).json({ message: 'Invalid data format' });
        }

        await personCollection.updateOne(
            { _id: new ObjectId(personId) },
            { $set: updateField }
        );

        res.json({ message: 'Contact information updated successfully' });

    } catch (error) {
        console.error('Error updating contact information:', error);
        return res.status(500).json({ message: 'Internal server error' });
    }
};