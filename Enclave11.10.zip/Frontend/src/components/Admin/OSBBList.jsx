import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import {
    Card,
    Input,
    Checkbox,
    Button,
    Typography,
    Alert,
} from "@material-tailwind/react";

const OSBBList = () => {
    const [OSBBList, setOSBBList] = useState([]);
    const token = localStorage.getItem('token');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchOSBB = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/osbblist`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setOSBBList(response.data);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchOSBB();
    }, []);

    const handleOSBBClick = async (OSBBId) => {
        try {
            localStorage.setItem("OSBBId", OSBBId);
            navigate(`/admin/${OSBBId}`);
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };

    const handleOSBBAdd = async() => {
        navigate(`/admin/add-OSBB-data`);
    }

    return (
        <div style={{height: '100%'}}>
            <h1>Список ОСББ</h1>
            <ul>
            {OSBBList.map(OSBB => (
                <li key={OSBB._id} onClick={() => handleOSBBClick(OSBB._id)}>
                    {OSBB.name}
                </li>
            ))}
            </ul>
            <Button className="mt-6" onClick={() => handleOSBBAdd()} variant="gradient" color="blue">
                Добавить
            </Button>
        </div>
    );
};

export default OSBBList;