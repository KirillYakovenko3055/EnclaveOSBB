import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Owners = () => {
    const [owners, setOwners] = useState([]);
    const token = localStorage.getItem('token');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchOwners= async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/owners`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setOwners(response.data);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchOwners();
    }, []);

    const handleOwnerClick = async (ownerId) => {
        try {
            localStorage.setItem("ownerId", ownerId);
            navigate(`/user/owner/${residentId}`);
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };

    return (
        <div style={{height: '100%'}}>
            <h1>Список счетчиков</h1>
            <h2>Ваши счетчики:</h2>
            <ul>
            {residents.map(resident => (
                <li key={measurer._id} onClick={() => handleOwnerClick(resident._id)}>
                    {resident.number}
                </li>
            ))}
            </ul>
        </div>
    );
};

export default Residents;