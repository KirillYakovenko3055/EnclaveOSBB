import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Residents = () => {
    const [residents, setResidents] = useState([]);
    const token = localStorage.getItem('token');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchResidents= async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/residents`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setResidents(response.data);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchResidents();
    }, []);

    const handleResidentClick = async (residentId) => {
        try {
            localStorage.setItem("residentId", residentId);
            navigate(`/user/resident/${residentId}`);
        } catch (error) {
            console.error('Ошибка получения данных по счету:', error);
        }
    };

    return (
        <div style={{height: '100%'}}>
            <h1>Список счетчиков</h1>
            <h2>Ваши счетчики:</h2>
            <ul>
            {residents.map(resident => (
                <li key={measurer._id} onClick={() => handleResidentClick(resident._id)}>
                    {resident.number}
                </li>
            ))}
            </ul>
        </div>
    );
};

export default Residents;