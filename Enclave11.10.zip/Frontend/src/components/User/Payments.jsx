import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Payments = () => {
    const [payments, setPayments] = useState([]);
    const token = localStorage.getItem('token');
    const accountId = localStorage.getItem('accountId');

    useEffect(() => {
        const fetchPayments = async () => {
            try {
                const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/api/user/payments/${accountId}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });

                setPayments(response.data);
            } catch (error) {
                console.error('Ошибка получения счетов:', error);
            }
        };

        fetchPayments();
    }, []);
    const sortedPayments = payments.sort((a, b) => new Date(b.date) - new Date(a.date));

    return (
        <div style={{height: '100%'}}>
            <h1>История оплат</h1>
            <ul>
            {sortedPayments.map(payment => (
                <li key={payment._id} onClick={() => handleMeasurerClick(payment._id)}>
                    <div>Тип оплаты: {payment.type}</div>
                    <div>Сумма оплаты: {payment.sum} Гривен</div>
                    <div>Дата оплаты: {new Date(payment.date).toISOString().split('T')[0]}</div>
                </li>
            ))}
            </ul>
        </div>
    );
};

export default Payments;