import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import logo from './logo_png.png';
import {
  Menu,
  MenuHandler,
  MenuList,
  MenuItem,
  Avatar,
  Button,
  Typography,
  IconButton,
  Collapse,
  Navbar,
} from "@material-tailwind/react";
import {
  ChevronDownIcon,
  UserCircleIcon,
  Cog6ToothIcon,
  PowerIcon,
  Bars2Icon,
  BanknotesIcon,
  BuildingOfficeIcon,
  CalendarDaysIcon,
  PhoneIcon,
} from "@heroicons/react/24/solid";

const profileMenuItems = [
  { label: "Services", icon: UserCircleIcon, path: "/resident/services" },
  { label: "Measurers", icon: Cog6ToothIcon, path: "/resident/measurers" },
  { label: "Sign Out", icon: PowerIcon },
];

function ProfileMenu() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const navigate = useNavigate();
  const accountId = localStorage.getItem('accountId');

  const closeMenu = () => setIsMenuOpen(false);

  const handleMenuClick = (item) => {
    if (item.path) {
      navigate(item.path + `/${accountId}`);
    } else if (item.label === "Sign Out") {
      localStorage.removeItem("accountId");
      localStorage.removeItem("token");
      navigate("/");
      window.location.reload();
    }
    closeMenu();
  };

  return (
    <Menu open={isMenuOpen} handler={setIsMenuOpen} placement="bottom-end">
      <MenuHandler>
        <Button variant="text" color="blue-gray" className="flex items-center gap-1 rounded-full py-0.5 pr-2 pl-0.5">
          <Avatar
            variant="circular"
            size="sm"
            alt="Profile"
            className="border border-gray-900 p-0.5"
            src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?auto=format&fit=crop&w=1480&q=80"
          />
          <ChevronDownIcon strokeWidth={2.5} className={`h-3 w-3 transition-transform ${isMenuOpen ? "rotate-180" : ""}`} />
        </Button>
      </MenuHandler>
      <MenuList className="p-1">
        {profileMenuItems.map((item, key) => (
          <MenuItem
            key={item.label}
            onClick={() => handleMenuClick(item)}
            className="flex items-center gap-2 rounded"
          >
            {React.createElement(item.icon, { className: `h-4 w-4` })}
            <Typography as="span" variant="small" className="font-normal">
              {item.label}
            </Typography>
          </MenuItem>
        ))}
      </MenuList>
    </Menu>
  );
}

const navListItems = [
  { label: "Правління", icon: BuildingOfficeIcon, location: "/a" },
  { label: "Збори", icon: CalendarDaysIcon, location: "/a" },
  { label: "Контакти", icon: PhoneIcon, location: "/about" },
  { label: "Тарифи", icon: BanknotesIcon, location: "/a" },
  { label: "Логін", icon: BanknotesIcon, location: "/login" },
]

function NavList() {
  return (
    <ul className="mt-2 mb-4 flex flex-col gap-16 lg:mb-0 lg:mt-0 lg:flex-row lg:items-center">
      {navListItems.map(({ label, icon, location }, key) => (
        <Typography
          key={label}
          as="a"
          href="#"
          variant="small"
          color="gray"
          className="font-medium text-blue-gray-500"
        >
          <MenuItem className="flex items-center gap-2 lg:rounded-full">
            {React.createElement(icon, { className: "h-[18px] w-[18px]" })}
            <Link to={location}>
              <span className="text-gray-900"> {label}</span>
            </Link>
          </MenuItem>
        </Typography>
      ))}
    </ul>
  );
}

export function ComplexNavbar() {
  const [isNavOpen, setIsNavOpen] = React.useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false); 
  const navigate = useNavigate();

  const toggleIsNavOpen = () => setIsNavOpen((cur) => !cur);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token); 
  }, []); 

  const handleLoginClick = () => {
    navigate("/login");
  };

  return (
    <Navbar className="mx-auto p-2 lg:pl-6" style={{ marginTop: "15px", maxWidth:"2000px" }}>
      <div className="relative mx-auto flex items-center justify-between text-blue-gray-900">
        <Typography as="a" href="/" className="mr-4 ml-2 cursor-pointer py-1.5 font-large" variant="h4" color="blue">
          <Link to="/"><Avatar style={{ width: "8rem" }} src={logo}></Avatar></Link>
        </Typography>
        <div className="hidden lg:block">
          <NavList />
        </div>
        <IconButton size="sm" color="blue-gray" variant="text" onClick={toggleIsNavOpen} className="ml-auto mr-2 lg:hidden">
          <Bars2Icon className="h-6 w-6" />
        </IconButton>
        {isLoggedIn ? (
          <ProfileMenu />
        ) : (
          <Button variant="gradient" onClick={handleLoginClick}>
            Логин
          </Button>
        )}
      </div>
      <Collapse open={isNavOpen} className="overflow-scroll">
        <NavList />
      </Collapse>
    </Navbar>
  );
}

export default ComplexNavbar;
