import React, { Component } from 'react';
import { Spinner } from "@material-tailwind/react";
import './Main.css';

export default class EditUser extends Component {
constructor(props){
    super(props);

    this.state={
    };
}

render() {
    return (
        <div>
        <div class="intro back1">
            <h1 class>ОСББ</h1>
            <h1>"THE ENCLAVE"</h1>
            <p>Ми є спільнота мешканців, що забезпечує комфорт, безпеку та ефективне управління будинком.</p>
        </div>
        <div class="wimg">
        <div class="achievements">
            <div class="work">
                <Spinner color="pink" className="h-8 w-8"/>
                <p class="work-heading">5498</p>
                <p class="work-text">OSBB</p>
            </div>
            <div class="work">
                <Spinner color="pink" className="h-8 w-8"/>
                <p class="work-heading">1259</p>
                <p class="work-text">ВДЯЧНИХ КОРИСТУВАЧІВ</p>
            </div>
        </div>
        <div class="about-me">
            <div class="about-me-text">
                <h2>ПРO НАС</h2>
                <p> ОСББ «Enclave» — це сучасний житловий комплекс, який втілює найкращі традиції надійного та комфортного проживання. Ми забезпечуємо ефективне управління та підтримку всіх житлових процесів, створюючи безпечне і затишне середовище для мешканців.

Наш підхід базується на принципах довіри, прозорості та відповідальності. Ми прагнемо до того, щоб кожен мешканець відчував себе у повній безпеці та комфорті, знаючи, що його будинок під надійним захистом.

ОСББ «Enclave» — це ваш надійний партнер у питаннях управління житлом. Вибираючи нас, ви обираєте стабільність, якість та безпеку для вашої родини.  </p>
            </div>
        </div>
    </div></div>
    )
    }
}